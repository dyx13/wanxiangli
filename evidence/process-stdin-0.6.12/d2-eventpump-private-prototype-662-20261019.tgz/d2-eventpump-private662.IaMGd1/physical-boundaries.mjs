import assert from 'node:assert/strict'
import { closeSync, existsSync, mkdirSync, mkdtempSync, openSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import { join } from 'node:path'
import { setTimeout as delay } from 'node:timers/promises'
import { SupervisedProcess } from './node_modules/wanxiangshu/node_modules/wanxiangli/dist/supervision/SupervisedProcess.js'

const root = '/private/tmp/d2-eventpump-private662.IaMGd1'
const evidence = join(root, 'physical-boundaries')
mkdirSync(evidence, { recursive: true })
const scratch = mkdtempSync('/private/tmp/d2-eventpump-boundary-')
const sessions = []
const results = []
const waitFor = async (read, description) => {
  const limit = performance.now() + 5000
  while (performance.now() < limit) {
    const value = read()
    if (value) return value
    await delay(5)
  }
  throw new Error(description)
}
const state = pid => {
  const result = spawnSync('/bin/ps', ['-p', String(pid), '-o', 'stat='], { encoding: 'utf8' })
  return result.status === 0 ? result.stdout.trim() : null
}
const capture = async session => {
  const chunks = { stdout: [], stderr: [] }
  while (true) {
    const value = await session.takeOutput()
    if (value.kind !== 'Chunk') return { terminal: value, stdout: Buffer.concat(chunks.stdout), stderr: Buffer.concat(chunks.stderr) }
    chunks[value.channel].push(Buffer.from(value.bytes))
  }
}
try {
  for (const partial of [false, true]) {
    const label = partial ? 'read-64KiB-then-close' : 'close-before-parent-write'
    const folder = join(scratch, label)
    mkdirSync(folder)
    const ready = join(folder, 'ready')
    const gate = join(folder, 'continue')
    const witness = join(folder, 'target')
    const target = `const fs=require('node:fs'); const input=Buffer.alloc(${partial ? 65536 : 0}); let received=0; while(received<input.length){const n=fs.readSync(0,input,received,input.length-received,null);if(n===0)break;received+=n;} fs.writeFileSync(${JSON.stringify(witness)},input.subarray(0,received)); fs.closeSync(0); fs.writeFileSync(${JSON.stringify(ready)},String(process.pid)); const timer=setInterval(()=>{if(!fs.existsSync(${JSON.stringify(gate)}))return;clearInterval(timer);for(const [fd,size,value] of [[1,2097169,65],[2,2097175,66]]){const bytes=Buffer.alloc(size,value);let pos=0;while(pos<bytes.length){const n=fs.writeSync(fd,bytes,pos,bytes.length-pos);if(n<=0)throw new Error('No progress');pos+=n;}}process.exit(23);},5);`
    const session = new SupervisedProcess({ executable: '/opt/homebrew/bin/node', args: ['-e', target], cwd: folder, env: {}, tailBytes: 0, maxWriteBytes: 16777216 })
    sessions.push(session)
    const captured = capture(session)
    const started = await session.started()
    assert.equal(started.kind, 'Started')
    const input = Buffer.alloc(2097169)
    for (let index = 0; index < input.length; index++) input[index] = index % 251
    if (!partial) await waitFor(() => existsSync(ready), 'The real target must close fd0 before the parent write')
    const pending = session.write(input)
    await waitFor(() => existsSync(ready), 'The real target must close fd0 after exactly 64KiB')
    const targetPid = Number(readFileSync(ready, 'utf8'))
    assert.equal(targetPid, started.pid)
    const supervisorPid = session.inspect().supervisor.pid
    const trace = await waitFor(() => {
      if (!existsSync(join(root, 'pump-trace.jsonl'))) return null
      return readFileSync(join(root, 'pump-trace.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line)).find(row => row.pid === supervisorPid && row.outcome === 'target-rejected')
    }, 'The real target rejection must be observed before releasing its later output')
    assert.ok(state(targetPid) && !state(targetPid).startsWith('Z'))
    const actual = readFileSync(witness)
    assert.equal(actual.length, partial ? 65536 : 0)
    assert.deepEqual(actual, input.subarray(0, actual.length))
    writeFileSync(gate, 'release after observed input rejection')
    const write = await pending
    session.endInput()
    const output = await captured
    assert.equal(output.terminal.kind, 'Closed')
    assert.equal(output.terminal.state.failure, null)
    assert.deepEqual(output.terminal.state.exit, { code: 23, signal: null })
    assert.deepEqual(output.stdout, Buffer.alloc(2097169, 65))
    assert.deepEqual(output.stderr, Buffer.alloc(2097175, 66))
    writeFileSync(join(evidence, label + '.input.bin'), input)
    writeFileSync(join(evidence, label + '.target.bin'), actual)
    writeFileSync(join(evidence, label + '.stdout.bin'), output.stdout)
    writeFileSync(join(evidence, label + '.stderr.bin'), output.stderr)
    const result = { passed: true, label, started, targetPid, supervisorPid, trace, write, terminal: output.terminal, targetBytes: actual.length, outputBytes: { stdout: output.stdout.length, stderr: output.stderr.length }, writeCalls: 1, noRetry: true, rejectionObservedBeforeOutputGateRelease: true, targetContinuedAfterRejection: true }
    results.push(result)
    writeFileSync(join(evidence, label + '.json'), JSON.stringify(result, null, 2) + '\n')
    console.log(JSON.stringify(result))
  }

  {
    const folder = join(scratch, 'directory-stdin')
    mkdirSync(folder)
    const ready = join(folder, 'target-ready')
    const target = `require('node:fs').writeFileSync(${JSON.stringify(ready)},String(process.pid)); setInterval(()=>{},1000);`
    const request = { executable: '/opt/homebrew/bin/node', args: ['-e', target], cwd: folder, env: {}, tailBytes: 0, maxWriteBytes: 16777216 }
    writeFileSync(join(folder, 'request'), JSON.stringify(request))
    const directoryFd = openSync(folder, 'r')
    const stdoutPath = join(evidence, 'directory-stdin.stdout')
    const stderrPath = join(evidence, 'directory-stdin.stderr')
    const stdout = openSync(stdoutPath, 'w')
    const stderr = openSync(stderrPath, 'w')
    let child
    let targetPid
    try {
      child = Bun.spawn(['/opt/homebrew/bin/bun', join(root, 'node_modules/wanxiangshu/node_modules/wanxiangli/dist/supervision/SupervisedProcess.js'), '--wanxiangli-supervisor', folder], { cwd: folder, env: {}, stdin: directoryFd, stdout, stderr, detached: true })
      closeSync(directoryFd)
      closeSync(stdout)
      closeSync(stderr)
      const fault = await waitFor(() => existsSync(join(folder, 'fault')) ? JSON.parse(readFileSync(join(folder, 'fault'), 'utf8')) : null, 'A real directory-fd input read must publish its source error')
      targetPid = await waitFor(() => existsSync(ready) ? Number(readFileSync(ready, 'utf8')) : null, 'The owned target must start for cleanup evidence')
      const controls = {}
      for (const name of ['request', 'started', 'fault', 'exit', 'closed']) if (existsSync(join(folder, name))) controls[name] = JSON.parse(readFileSync(join(folder, name), 'utf8'))
      const result = { label: 'actual-directory-fd0-source-read-error', fault, controls, supervisorPid: child.pid, targetPid, scope: 'Actual Worker entry with inherited owned directory fd0. No emitted error or replaced filesystem operation. This is a physical read-error fixture, not public Host admission.' }
      writeFileSync(join(evidence, 'directory-stdin.json'), JSON.stringify(result, null, 2) + '\n')
      console.log(JSON.stringify(result))
      assert.equal(fault.operation, 'stdin')
      assert.equal(fault.code, 'EISDIR')
      assert.equal(controls.closed, undefined)
      assert.equal(controls.exit, undefined)
      results.push({ ...result, passed: true, noExitInferredFromInputError: true })
    } finally {
      if (child) {
        try { process.kill(-child.pid, 'SIGKILL') } catch (_) {}
        await child.exited
      }
      for (const descriptor of [directoryFd, stdout, stderr]) { try { closeSync(descriptor) } catch (_) {} }
      if (targetPid) await waitFor(() => { const actual = state(targetPid); return actual === null || actual.startsWith('Z') }, 'The owned error-case target must stop executing')
    }
  }
  writeFileSync(join(evidence, 'summary.json'), JSON.stringify({ passed: true, cases: results, scope: 'One private event/readable pump candidate, two gated real target rejection cases and one actual directory-fd source read error. No shared source edits and no production acceptance.' }, null, 2) + '\n')
} finally {
  for (const session of sessions) {
    session.signal('SIGKILL')
    session.discardOutput()
    await session.wait(5000)
  }
  rmSync(scratch, { recursive: true, force: true })
  console.log(JSON.stringify({ cleanup: true, scratchRemoved: !existsSync(scratch) }))
}
