import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { setTimeout as delay } from 'node:timers/promises'

const evidence = path.resolve(process.argv[2])
const libraries = process.argv.slice(3).map(value => path.resolve(value))
assert.equal(libraries.length, 2)
mkdirSync(evidence, { recursive: true })
const input = Uint8Array.from({ length: 2097169 }, (_, index) => index % 256)
input.set([239, 187, 191], 0)
writeFileSync(path.join(evidence, 'input.bin'), input)
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const describe = bytes => ({ bytes: bytes.length, sha256: sha(bytes), first: bytes.subarray(0, 12).toString('hex'), last: bytes.subarray(-12).toString('hex') })
const packageBytes = root => {
  const files = []
  const walk = directory => {
    for (const name of readdirSync(directory).sort()) {
      const file = path.join(directory, name)
      if (statSync(file).isDirectory()) walk(file)
      else files.push([path.relative(root, file), sha(readFileSync(file))])
    }
  }
  walk(root)
  return { files: files.length, sha256: sha(JSON.stringify(files)) }
}
const records = []
const until = async (predicate, message) => {
  const deadline = Date.now() + 5000
  while (!predicate()) {
    assert.ok(Date.now() < deadline, message)
    await delay(5)
  }
}
const notActive = pid => {
  let state
  try { state = execFileSync('/bin/ps', ['-o', 'stat=', '-p', String(pid)], { encoding: 'utf8' }).trim() }
  catch (error) { if (error.status === 1) return true; throw error }
  return state.length === 0 || state.startsWith('Z')
}

for (const library of libraries) {
  const metadata = JSON.parse(readFileSync(path.join(library, 'package.json'), 'utf8'))
  const before = packageBytes(library)
  const exported = metadata.exports['./supervision'].import
  const { SupervisedProcess } = await import(pathToFileURL(path.join(library, exported)).href)
  const scratch = mkdtempSync(path.join(tmpdir(), `d2-compare-${metadata.version}-`))
  const targetFile = path.join(scratch, 'target.bin')
  const readyFile = path.join(scratch, 'ready')
  const alias = "alias.d2-status=!f() { printf ready > \"$3\"; tee \"$2\"; printf '\\000\\377stderr\\n' >&2; exit \"$1\"; }; f"
  execFileSync('/usr/bin/git', ['-C', scratch, 'init', '--quiet'])
  const run = new SupervisedProcess({ executable: '/usr/bin/git', args: ['-C', scratch, '-c', alias, 'd2-status', '7', targetFile, readyFile], cwd: scratch, env: { PATH: process.env.PATH }, tailBytes: 0, maxWriteBytes: 16777216 })
  const record = { version: metadata.version, library, packageBefore: before, writeCalls: 0, started: null, write: null, kill: null, terminal: null, closed: null }
  records.push(record)
  const stdout = []
  const stderr = []
  const collected = (async () => {
    while (true) {
      const output = await run.takeOutput()
      if (output.kind !== 'Chunk') { record.terminal = output; return }
      if (output.channel === 'stdout') stdout.push(Buffer.from(output.bytes))
      else stderr.push(Buffer.from(output.bytes))
    }
  })()
  let watchdog
  try {
    watchdog = setTimeout(() => run.signal('SIGKILL'), 8000)
    record.started = await run.started()
    assert.equal(record.started.kind, 'Started')
    record.supervisor = run.inspect().supervisor.pid
    await until(() => existsSync(readyFile) && existsSync(targetFile), 'The actual tee was not ready')
    record.targetReadyBeforeInput = true
    record.writeCalls++
    record.write = await run.write(input)
    if (record.write.kind === 'Unknown') record.kill = run.signal('SIGKILL')
    else {
      assert.deepEqual(record.write, { kind: 'Written', bytes: input.length })
      run.endInput()
    }
    record.closed = await run.wait(5000)
    assert.equal(record.closed.kind, 'Closed')
    await collected
  } finally {
    clearTimeout(watchdog)
    if (run.inspect().phase !== 'Closed') {
      record.cleanupKill = run.signal('SIGKILL')
      run.discardOutput()
      record.cleanupWait = await run.wait(5000)
      await collected
    }
    record.finalState = run.inspect()
    const actual = existsSync(targetFile) ? readFileSync(targetFile) : null
    const output = Buffer.concat(stdout)
    const diagnostic = Buffer.concat(stderr)
    record.stdout = describe(output)
    record.stderr = describe(diagnostic)
    record.target = actual ? describe(actual) : null
    record.targetMatchesAllInput = actual?.equals(Buffer.from(input)) ?? false
    record.targetPrefixMatchesInput = actual?.equals(Buffer.from(input).subarray(0, actual.length)) ?? false
    record.outputMatchesTarget = actual?.equals(output) ?? false
    writeFileSync(path.join(evidence, `${metadata.version}.stdout.bin`), output)
    writeFileSync(path.join(evidence, `${metadata.version}.stderr.bin`), diagnostic)
    if (actual) writeFileSync(path.join(evidence, `${metadata.version}.target.bin`), actual)
    if (record.started.kind === 'Started') await until(() => notActive(record.started.pid) && notActive(record.supervisor), 'An owned target or supervisor stayed active')
    record.cleanup = { targetInactive: notActive(record.started.pid), supervisorInactive: notActive(record.supervisor) }
    rmSync(scratch, { recursive: true, force: true })
    record.scratchRemoved = !existsSync(scratch)
    record.packageAfter = packageBytes(library)
    assert.deepEqual(record.packageAfter, before)
  }
}

const result = { host: process.versions.bun ? `Bun ${process.versions.bun}` : `Node ${process.version}`, input: describe(Buffer.from(input)), records }
writeFileSync(path.join(evidence, 'summary.json'), JSON.stringify(result, null, 2))
console.log(JSON.stringify(result, null, 2))
