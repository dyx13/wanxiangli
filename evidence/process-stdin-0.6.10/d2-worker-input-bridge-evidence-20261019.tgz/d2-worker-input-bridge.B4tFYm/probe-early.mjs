import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = '/private/tmp/d2-clean-install-659/node_modules/wanxiangshu'
const evidence = process.argv[2]
mkdirSync(evidence, { recursive: true })
const library = join(product, 'node_modules/wanxiangli/dist/process/ProcessSession.js')
const { ProcessSession } = await import(pathToFileURL(library))
const scratch = mkdtempSync('/private/tmp/d2-worker-input-early-')
const input = Uint8Array.from({ length: 2097169 }, (_, index) => index % 256)
input.set([239, 187, 191], 0)
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const results = []
const handles = []
try {
  for (const mode of ['serial', 'serial-preserve', 'serial-drain']) {
    const repo = join(scratch, mode)
    mkdirSync(repo)
    const witness = join(repo, 'target-input.bin')
    const trace = join(repo, 'bridge-trace.json')
    const session = new ProcessSession({ executable: '/opt/homebrew/bin/bun', args: ['/private/tmp/d2-worker-input-bridge.B4tFYm/bridge-early.mjs', mode, repo, witness, trace], cwd: repo, env: { PATH: process.env.PATH }, tailBytes: 0, maxWriteBytes: 16777216 }, 'Capture')
    handles.push(session)
    const channels = { stdout: [], stderr: [] }
    const capture = (async () => {
      while (true) {
        const output = await session.takeOutput()
        if (output.kind !== 'Chunk') return output
        channels[output.channel].push(Buffer.from(output.bytes))
      }
    })()
    const started = await session.started()
    assert.equal(started.kind, 'Started')
    const write = await session.write(input)
    session.endInput()
    const terminal = await capture
    const closed = await session.wait(1000)
    const stdout = Buffer.concat(channels.stdout)
    const stderr = Buffer.concat(channels.stderr)
    const actual = readFileSync(witness)
    const bridgeTrace = JSON.parse(readFileSync(trace, 'utf8'))
    writeFileSync(join(evidence, `${mode}.trace.json`), JSON.stringify(bridgeTrace, null, 2) + '\n')
    writeFileSync(join(evidence, `${mode}.target.bin`), actual)
    writeFileSync(join(evidence, `${mode}.stdout.bin`), stdout)
    writeFileSync(join(evidence, `${mode}.stderr.bin`), stderr)
    assert.ok(actual.length > 0 && actual.length <= 65536)
    assert.deepEqual(actual, Buffer.from(input).subarray(0, actual.length))
    assert.deepEqual(stdout, Buffer.alloc(2097169, 65))
    assert.deepEqual(stderr, Buffer.alloc(2097175, 66))
    assert.deepEqual(bridgeTrace.targetExit, { code: 23, signal: null })
    const result = { mode, host: process.execPath, started, write, terminal, closed, targetRead: { bytes: actual.length, sha256: sha(actual) }, stdout: { bytes: stdout.length, sha256: sha(stdout) }, stderr: { bytes: stderr.length, sha256: sha(stderr) }, bridgeTrace, scope: 'Private early-input-close control using actual fixed NativeSpawn/NativeOutput and outer ProcessSession. Actual Node target reads at most64KiB then closes stdin, writes both channels over2MiB under backpressure, and exits23. Input-source abort behavior is observed; this is not the final library fix.' }
    results.push(result)
    console.log(JSON.stringify(result))
  }
  writeFileSync(join(evidence, 'summary.json'), JSON.stringify({ results }, null, 2) + '\n')
} finally {
  for (const session of handles) {
    session.signal('SIGKILL')
    session.discardOutput()
    await session.wait(5000)
  }
  rmSync(scratch, { recursive: true, force: true })
  console.log(JSON.stringify({ cleanup: true, scratchRemoved: !existsSync(scratch) }))
}
