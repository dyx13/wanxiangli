# D2 stdin independent review, 2026-10-18

The candidate is the fixed `wanxiangli-0.6.9.tgz`, SHA256
`c0ed8fe889fe4e49cd19c7ae092c23892fdd9a73773c73ad40c8380ba409bd32`.
The baseline is the previously delivered `wanxiangli-0.6.8.tgz`, SHA256
`7e5873932a9ddd4519115f5575eda46f09c0f37d50ad4e97def05dbaba76022b`.
Both were actually installed by npm with lifecycle scripts disabled, using a
private cache. They have no runtime package dependencies or borrowed source.

## Result and attribution

The same public ESM consumer passed nine independent scenarios on Node 26.6.0
and nine on Bun 1.3.14, Darwin arm64. The fixed baseline passed all nine on
Node; on Bun its first large-input positive control failed with
`Unknown/ERR_STREAM_DESTROYED: Only 131072 of 16777216 input bytes were acknowledged`.
That guard is present in library commit `ca238c0502cb1dca7844f06528d8332440a2b967`.
This is a regression from that earlier Bun I/O repair, not an original module
extraction defect and not a new D1 regression.

The implementation change removes only the stdin immediate-count comparison.
It still awaits `FileSink.flush()`, retains the pending-write rejection on
exit, and retains errors from write/flush. It does not retry or resubmit bytes.
The native output FileSink count guard is outside this change.

The candidate's 22 installed package files had the same aggregate digest
before and after both final hosts:
`c0df8149dba3190321a2ac54061aba4622aee2a0404ee90c44ef414fa6ae829e`.
The baseline's 22 package files also remained unchanged. This aggregate hashes
the sorted `[relative path, SHA256]` pairs, not tar encoding.

## Independent scenarios

For base ProcessSession, all five passed on each candidate host:

1. A real delayed reader receives exactly 32 MiB + 17 bytes, in writes of
   16 MiB, 16 MiB, and 17. Each receipt is Written with that exact size.
   A separately saved target-side byte count and SHA256 match the input;
   exit is 0 and failure is null.
2. A target confirms it has not read stdin; a 16 MiB write remains pending
   for 200 ms. Killing the owned group yields Unknown, with no retry.
3. A target closes fd 0 but stays alive. A 16 MiB write yields actual EPIPE
   and Unknown while the target still runs; the public input state rejects
   later writes. The owned group is then killed.
4. The target reads exactly one byte and stays alive. The full 16 MiB write
   remains pending, and group termination yields Unknown.
5. The target reads exactly one byte and exits 23 during the large pending
   write. The result is Unknown and the actual target exit 23 is retained.

For SupervisedProcess, all four passed on each candidate host:

1. The same exact 32 MiB + 17 bytes reach the target once, with target-side
   byte count and hash, complete Capture, exit 0, and no failure.
2. A target never reads; the owned supervisor is physically SIGSTOPped and
   its stopped state is checked with ps before the large write. The first
   pipe remains pending; group termination yields Unknown.
3. The target has closed fd 0 while staying alive. The owned supervisor is
   stopped before the large write, establishing the same actual pending
   first-pipe boundary. Group termination yields Unknown.
4. One byte is Written and the target records exactly one byte consumed.
   The supervisor is then stopped before a 16 MiB write. That write stays
   pending and group termination yields Unknown.

Every final scenario reached Closed, every recorded target and supervisor
was sampled with ps as absent or a non-running zombie, and each scenario's
scratch directory was removed. `cleanup-samples.json` additionally samples
all 64 PIDs recorded by the baseline, candidate and earlier fixture runs;
none was active. Closed with `UNKNOWN_TARGET_EXIT` after killing a stopped
supervisor remains an unknown target receipt; it is not reported as exit 0.

## Types and removal gate

The unmodified `SPEC[build-007]` gate was pointed at the fixed 0.6.9 tarball.
Its five Node test-runner results passed, with no skip:

- Real npm installation, no runtime dependencies, and TypeScript 7.0.2 strict
  compilation against the installed public declarations, including negative
  `@ts-expect-error` assertions.
- After deleting unrelated module dist/source and all F# source/declarations,
  actual Node and Bun public supervision consumers preserve dual 8 MiB + 22
  byte output hashes and the live group identity after target exit 23.
- After also deleting dist/supervision, actual Node and Bun public process
  consumers still run correctly.

The TypeScript executable is a declared test-only tool from the library
checkout. No implementation source is compiled or used by those runtime
consumers. The frozen fixtures and gate are included for portable reruns.

## Review misjudgments retained

An initial probe used `createRequire().resolve()` on import-only ESM exports.
It failed before importing or starting product code. The probe now uses actual
ESM import conditions from the separate clean-install consumer directory.

An initial supervised negative asserted that a target which never reads must
make the outer first-pipe write pending. Bun falsified that premise: a 16 MiB
write was Written because the supervisor had already taken those bytes into
its runtime/forwarding queues. The receipt belongs to the supervisor input
pipe, as the existing AGENTS and .d.ts contract state. This was a review fixture
misjudgment, not evidence of a product regression. The corrected negative
physically stops the owned supervisor before writing. The invalid raw run is
retained and its processes were cleaned.

This review does not prove a total memory bound for the supervisor's input
queues. It does not promote first-pipe Written to proof of final-target
consumption, provide a Linux result, or close D2 GitStore work or R12-U1.

The first npm attempt used the default user cache and received filesystem
EPERM. The private-cache retry succeeded. No cache ownership was changed.

## Portable rerun

Extract this archive, then enter its `D2-STDIN-069` directory. Use Node/Bun on
a POSIX host with `/bin/ps`, `/usr/bin/mkfifo`, and FIFO support. Set D2_NODE
to the absolute Node executable used for the actual test targets. The default
in the probe is the recorded macOS path; override it elsewhere.

```sh
mkdir consumer
npm install --prefix consumer --cache "$PWD/npm-cache" --ignore-scripts --no-audit --no-fund "$PWD/candidate/wanxiangli-0.6.9.tgz"
cp probe.mjs consumer/probe.mjs
D2_NODE="$(command -v node)" node consumer/probe.mjs "$PWD/consumer/node_modules/wanxiangli" > node-stdin.json
D2_NODE="$(command -v node)" bun consumer/probe.mjs "$PWD/consumer/node_modules/wanxiangli" > bun-stdin.json
```

To reproduce the old Bun red, create a different consumer directory and run
the same probe after installing `baseline/wanxiangli-0.6.8.tgz`. An exit status
of 1 at its first positive control is expected and must not count as green.

To repeat the independent package/type/removal gate, install the test-only
TypeScript version in the included gate directory and run the frozen test:

```sh
npm install --prefix gate --cache "$PWD/npm-cache" --no-audit --no-fund typescript@7.0.2
WANXIANGLI_TEST_TARBALL="$PWD/candidate/wanxiangli-0.6.9.tgz" node --test gate/scripts/tests/supervision-package.test.mjs
```

`MANIFEST.sha256` hashes every evidence file except itself. Verify it from
the archive root with `shasum -a 256 -c MANIFEST.sha256` before rerunning.
