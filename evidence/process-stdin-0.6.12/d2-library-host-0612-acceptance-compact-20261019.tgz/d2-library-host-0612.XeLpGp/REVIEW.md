# Fixed 0.6.12 physical package acceptance

This is actual fixed-package acceptance by a reviewer who participated in the
earlier private pump prototype. It is not claimed as a non-author algorithm
review. The package SHA256 is
`a039ba669299c6919776196fd9b462624bcbe515d03593804596dbc86f43ac56`.
It was independently installed with npm offline into this directory. No
production module was copied from or imported from either source workspace.

The two consumers are byte-identical to the frozen 0.6.11 consumers. Only their
installation/evidence arguments changed. Each Node and Bun CLI case ran once,
six cases per Host and twelve total:

- Real tee with 2 MiB + 17 and 32 MiB + 17 under delayed output consumption.
- Real Node reader with 64 MiB + 17. It reads at most 64 KiB, writes every byte
  to the actual witness and stdout, then waits 1 ms. Writes are 16 MiB chunks
  followed by the last 17 bytes.
- Real target closes stdin immediately, then emits over 2 MiB on each channel
  and exits 23.
- Real target accumulates exactly 64 KiB before closing stdin, emits both
  channels and exits 23. Actual input equals exactly that prefix.
- One physically pending 16 MiB write, established for 100 ms while the owned
  supervisor is stopped, resolves Unknown after public scope KILL. There is one
  input call, no retry, no invented target exit, and ps confirms owned target
  cleanup.

All twelve passed. Every complete target and stdout equals its generated input
byte for byte, including the final 17 bytes. All original large files were
written before the equality assertions. Both partial-input random originals
and their actual target/channel bytes are also preserved. Outer Written is not
used as proof that the target consumed the input.

No extra Bun test-mode matrix or unchanged FileSink callback controlled test
was repeated in this step. The earlier private prototype and its missing read
guard remain separate evidence; this package has the production read guard.
The main generation 663 consumers, typed boundaries and non-author algorithm
review are owned by other reviewers. These twelve finite physical cases do not
stand in for those checks or independently prove all process guarantees.

The compact archive retains all logs, summaries, raw receipts, code, package,
locks and smaller/nonreproducible byte witnesses. It omits only the successful
32 MiB + 17 and 64 MiB + 17 input/target/stdout files, whose complete hashes,
seeds and equality results remain in OMISSIONS.json and the full summaries.
The unabridged source directory remains at the path above. No full archive was
created for this step; there is no nonexistent full-archive hash to infer.

## Replay

From this directory, use the preserved exact installed package or install the
included exact tgz, then run each command once into a new evidence folder:

```sh
node library-input-consumer.mjs "$PWD" "$PWD/replay/node/input"
node partial-input-consumer.mjs "$PWD" "$PWD/replay/node/partial"
bun library-input-consumer.mjs "$PWD" "$PWD/replay/bun/input"
bun partial-input-consumer.mjs "$PWD" "$PWD/replay/bun/partial"
```

The CLI driver used an outer 50-second child guard; each actual physical case
also retains its smaller watchdog in source. No guard expired. Both code files
regenerate and retain the omitted successful bytes and assert equality. The
exact xorshift algorithm and seeds remain in source and each case summary.
