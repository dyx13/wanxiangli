import { appendFileSync } from 'node:fs'

export function forwardInput(source, target, failed) {
  let pending = false
  let stopped = false
  let ended = source.readableEnded
  let closed = source.closed
  const trace = { pid: process.pid, readCalls: 0, readBytes: 0, writeCalls: 0, writtenBytes: 0, events: [], outcome: null }
  const detach = () => {
    source.off('readable', pump)
    source.off('end', onEnd)
    source.off('close', onClose)
    source.off('error', onError)
  }
  const stop = (outcome, error) => {
    if (stopped) return
    stopped = true
    detach()
    trace.outcome = outcome
    trace.error = error ? { code: error.code ?? null, message: error.message } : null
    trace.source = { readableLength: source.readableLength, readableEnded: source.readableEnded, destroyed: source.destroyed, closed: source.closed }
    appendFileSync('/private/tmp/d2-eventpump-private662.IaMGd1/pump-trace.jsonl', JSON.stringify(trace) + '\n')
  }
  const fail = error => {
    if (stopped) return
    stop('source-fault', error)
    failed(error)
  }
  const finish = () => {
    stop('source-ended')
    try { target.end() }
    catch (_) {}
  }
  function pump() {
    if (stopped || pending) return
    let bytes
    try {
      trace.readCalls++
      bytes = source.read()
    } catch (error) {
      fail(error)
      return
    }
    if (bytes !== null) {
      pending = true
      trace.readBytes += bytes.length
      trace.writeCalls++
      try {
        target.write(bytes, error => {
          pending = false
          if (stopped) return
          if (error) {
            stop('target-rejected', error)
            return
          }
          trace.writtenBytes += bytes.length
          pump()
        })
      } catch (error) {
        pending = false
        stop('target-rejected', error)
      }
      return
    }
    if (ended || source.readableEnded) {
      finish()
      return
    }
    if (closed || source.closed || source.destroyed) {
      fail(Object.assign(new Error('Input source closed before a true end'), { code: 'ERR_STREAM_PREMATURE_CLOSE' }))
    }
  }
  function onEnd() {
    ended = true
    trace.events.push('end')
    pump()
  }
  function onClose() {
    closed = true
    trace.events.push('close')
    pump()
  }
  function onError(error) {
    trace.events.push('error')
    fail(error)
  }
  source.on('readable', pump)
  source.on('end', onEnd)
  source.on('close', onClose)
  source.on('error', onError)
  pump()
}
