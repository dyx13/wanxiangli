import assert from 'node:assert/strict'
import { mkdtempSync, readFileSync, rmSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { execFileSync } from 'node:child_process'

const library = path.resolve(process.argv[2])
const metadata = JSON.parse(readFileSync(path.join(library, 'package.json'), 'utf8'))
const { SupervisedProcess } = await import(pathToFileURL(path.join(library, metadata.exports['./supervision'].import)).href)
const scratch = mkdtempSync(path.join(tmpdir(), 'd2-early-close-'))
const run = new SupervisedProcess({ executable: '/bin/sh', args: ['-c', 'exec 0<&-; printf "before\n"; sleep 0.15; printf "after\n"; printf "diagnostic\n" >&2; exit 23'], cwd: scratch, env: { PATH: process.env.PATH }, tailBytes: 0, maxWriteBytes: 16777216 })
const record = { host: process.versions.bun ? `Bun ${process.versions.bun}` : `Node ${process.version}`, library, version: metadata.version }
const stdout = []
const stderr = []
const captured = (async () => {
  while (true) {
    const output = await run.takeOutput()
    if (output.kind !== 'Chunk') return output
    if (output.channel === 'stdout') stdout.push(Buffer.from(output.bytes))
    else stderr.push(Buffer.from(output.bytes))
  }
})()
let watchdog
try {
  watchdog = setTimeout(() => run.signal('SIGKILL'), 5000)
  record.started = await run.started()
  assert.equal(record.started.kind, 'Started')
  record.supervisor = run.inspect().supervisor.pid
  const bytes = new Uint8Array(2097169).fill(251)
  record.write = await run.write(bytes)
  if (record.write.kind === 'Written') assert.equal(record.write.bytes, bytes.length)
  else assert.equal(record.write.kind, 'Unknown')
  run.endInput()
  record.terminal = await captured
  record.closed = await run.wait(5000)
  record.stdout = Buffer.concat(stdout).toString()
  record.stderr = Buffer.concat(stderr).toString()
  assert.equal(record.closed.kind, 'Closed')
  assert.equal(record.closed.state.failure, null)
  assert.deepEqual(record.closed.state.exit, { code: 23, signal: null })
  assert.equal(record.stdout, 'before\nafter\n')
  assert.equal(record.stderr, 'diagnostic\n')
} finally {
  clearTimeout(watchdog)
  run.signal('SIGKILL')
  run.discardOutput()
  record.cleanup = await run.wait(5000)
  rmSync(scratch, { recursive: true, force: true })
  record.scratchRemoved = !existsSync(scratch)
  const state = pid => {
    try { return execFileSync('/bin/ps', ['-o', 'stat=', '-p', String(pid)], { encoding: 'utf8' }).trim() }
    catch (error) { if (error.status === 1) return ''; throw error }
  }
  record.pidStatesAfterClose = { target: state(record.started.pid), supervisor: state(record.supervisor) }
  for (const value of Object.values(record.pidStatesAfterClose)) assert.ok(value === '' || value.startsWith('Z'))
  console.log(JSON.stringify(record, null, 2))
}
