# Bounded 0.6.8 / 0.6.9 comparison

This supplements candidate 659's independent typed blocker evidence. It does
not replace that archive or establish that the old input relay was correct.

Both packages were immutable real npm installations, without source fallback:

- 0.6.8 archive SHA256: `7e5873932a9ddd4519115f5575eda46f09c0f37d50ad4e97def05dbaba76022b`.
- 0.6.9 archive SHA256: `c0ed8fe889fe4e49cd19c7ae092c23892fdd9a73773c73ad40c8380ba409bd32`.

Each host/version starts one real Git alias running tee, waits until tee has
created its private target file, then issues exactly one 2,097,169-byte write.
The input has BOM/NUL/0xff and all byte values, SHA256
`89aa92318e99cab08cca1c8f9e28532a8e261950c7421ad46e764e534358121d`.
An Unknown requests KILL immediately; a Written ends input normally. Neither
path resubmits the input. The target file and both captured binary channels
are retained separately, with before/after package digests and ps cleanup.

| Host | Package | Write receipt | Target bytes | End / failure |
| --- | --- | --- | ---: | --- |
| Node 26.6.0 | 0.6.8 | Written 2,097,169 | 2,097,169, exact hash | exit 7 / none |
| Node 26.6.0 | 0.6.9 | Written 2,097,169 | 2,097,169, exact hash | exit 7 / none |
| Bun 1.3.14 | 0.6.8 | Unknown, `ERR_STREAM_DESTROYED`, `Only 17 of 2097169...` | 122,880 before requested KILL | unknown target end / `UNKNOWN_TARGET_EXIT` |
| Bun 1.3.14 | 0.6.9 | Written 2,097,169 | 1,048,576, shortened prefix | exit 7 / none, Capture Closed |

The 0.6.9 guard removal changes this observable case from explicit Unknown to
undetected shortened delivery. This does not prove the old relay was correct:
its early rejection stops the old execution before normal relay/EOF completion
could be examined. It also does not justify restoring the incorrect immediate
FileSink-count guard. The separate minimum-bridge investigation owns the
precise pipe/EOF root cause and the repair.

Both installed packages' 22 files are unchanged. All four targets and all four
supervisors were sampled with ps as no longer active; all temporary repositories
were removed after saving evidence. The comparison script exits 0 when its
observation and cleanup procedure finishes; it is not a claim that both products
passed byte delivery. `targetMatchesAllInput` is false for both Bun observations.

Portable reproduction on a supported POSIX host:

```sh
mkdir old new
npm install --prefix old --cache "$PWD/npm-cache" --ignore-scripts --no-audit --no-fund "$PWD/wanxiangli-0.6.8.tgz"
npm install --prefix new --cache "$PWD/npm-cache" --ignore-scripts --no-audit --no-fund "$PWD/wanxiangli-0.6.9.tgz"
node d2-supervised-068-069-comparison.mjs node-observations "$PWD/old/node_modules/wanxiangli" "$PWD/new/node_modules/wanxiangli"
bun d2-supervised-068-069-comparison.mjs bun-observations "$PWD/old/node_modules/wanxiangli" "$PWD/new/node_modules/wanxiangli"
```

The probe uses `/usr/bin/git` and `/bin/ps`, matching this macOS environment.
It imports the exact installed module declared by each package's public
`./supervision` export and does not change either package.
