# Independent 0.6.12 Worker checkpoints

The exact archive is included: `wanxiangli-0.6.12.tgz`, SHA256 `a039ba669299c6919776196fd9b462624bcbe515d03593804596dbc86f43ac56`. It was actually installed using npm in a fresh directory with `--ignore-scripts --offline`. `clean-install/` retains its lock, install log and all 22 installed product files. Before/after hashes confirm that clean installation did not change.

`probe/consumer.mjs` and `probe/target.mjs` are the exact executed minimal consumers. `probe/wanxiangli` is a private copy of the fixed package. Only `dist/supervision/SupervisedProcess.js` changed, by adding a checkpoint wrapper and calling it on the actual Worker stdin/target pair. `probe/evidence/checkpoint-only.diff` preserves the exact wrapper. The production pump block itself is unchanged, verified separately. No second forwarding algorithm, fake target process or fake Readable replaced the implementation.

Three cases were preregistered and executed once per Host, Node 26.6.0 and Bun 1.3.14. All six passed:

- `read-end`: the wrapper calls actual native stdin.read to obtain the real 17 bytes, synchronously emits a deliberately controlled end event, then returns those actual bytes. No nested read or second in-flight write occurred; the actual target received all 17 bytes, observed EOF, produced both binary channels and exited 23.
- `read-error`: after the actual native read obtained 17 bytes, the wrapper synchronously emitted a deliberately controlled error and returned the actual bytes. The production pump reported stdin/D2_CONTROLLED_SOURCE_ERROR and made zero target.write and zero target.end calls. This checks the post-read stopped boundary. It is controlled event injection, not proof of a native OS stdin read fault. This case does not claim a known target exit; its target is terminated by the existing failure cleanup.
- `gate`: the actual Native target.write completed before its callback was held by the wrapper. The actual native source end event was observed while the callback remained held. At that checkpoint, pending=1, released callbacks=0, target.end calls=0, and the real target had not reached EOF. After the external release file, the unchanged pump ended once, the actual target saved the complete 17 bytes, both binary channels remained exact, and exit 23 was retained.

`probe/evidence/` contains the original preregistration, commands, stdout/stderr, target input originals, source/target checkpoints and actual final receipts. A separate unmodified-clean-package physical early-close probe was run once on each Host; both retained stdout `before\nafter\n`, stderr `diagnostic\n` and actual target exit 23 after closing fd0. Those two runs are separate physical I/O evidence, not part of the six preregistered controlled-event cases. Their exact reusable script is included as `d2-input-early-close.mjs`.

Replay uses the executed scripts and actual fixed package. The original checkpoint consumer has one literal target-script path, `/private/tmp/d2-0612-checkpoints/target.mjs`; restoring `probe/` at that exact private path permits the recorded commands to run unchanged with fresh output directories. The clean-package early-close script accepts any actual installed library path:

```sh
node d2-input-early-close.mjs "$fixed_library_directory"
bun d2-input-early-close.mjs "$fixed_library_directory"
```

The checkpoint wrapper insertion depends on generated Worker local names (`input_1`, `options`, `node$003Aprocess2`). It is retained as a reproducible fixed-artifact state-boundary probe. It is not presented as a stable cross-version semantic test or a reason to add a public test hook. Before promoting it to the library suite, its integration must be reviewed against the actual source/test boundary. No shared source was edited by this reviewer.

This evidence does not replace main-package real Git consumers, the original 19-case sequence or F# contract checking. Directory fd0 factory/worker failures are not claimed as pump stdin-error coverage. R12-U1 remains deferred.
