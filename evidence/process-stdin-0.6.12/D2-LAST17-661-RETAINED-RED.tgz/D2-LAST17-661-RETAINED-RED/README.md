# D2 candidate 661: retained last-17-byte failure

This is investigation evidence, not a passing acceptance. Node 26.6.0, Bun 1.3.14, macOS arm64, Git 2.50.1 (Apple Git-155).

The fixed main archive is included in `packages/`. SHA256: `34393e1d4b8fcb4b7e3ddbaa9769a681c728fb12ed072a0785c0bb82483f009f`. It embeds wanxiangli 0.6.10. The original installed package was not edited.

## Uninstrumented retained run

`retained-red/preregister.json` registered one full Bun 017 sequence before execution. `017-original.test.mjs`, `017-retained.test.mjs` and `allowed-edits.diff` preserve the exact source and changes: absolute fixed-product/tier-gate imports, absolute fixed-product cold-child import, and retention instead of the central repository deletion. The 19 test bodies were otherwise unchanged. Retention omits the original cleanup I/O; it is an explicit experimental confound.

The single run was 18 pass / 1 fail. The 32MiB+17 and 64MiB controls passed. The 64MiB+17 write returned `42ba1c977089a5c41722faca6d3f05b150ebc84b`; the full expected input is `81db9b92d4eb2b00c75faa776844aed47f5cac91`. Independent Node crypto and native Git with an input file descriptor agree on the expectation.

The failed repository is `repositories/wxs-binary-git-0GKk94`. A native Node cold reader sent native Git stdout directly to a file descriptor. Its object is exactly the first 67108864 bytes of the expected 67108881 bytes. All preceding bytes match; only the final 17 are absent. The preceding legitimate 64MiB control is separately retained as `repositories/wxs-binary-git-DIqmB6`; both repositories contain the same prefix OID. They must not be confused. `actual-earlier-64m.bin` is the legitimate control, not a second failed write.

`input-67108881.bin` was regenerated from the exact deterministic test rule (`index % 251`) after the failed run; it is not represented as an original Buffer dump. The failed object and cold-read bytes are actual retained outputs.

The private fixture's process-exit JSON handler did not execute under Bun test. `repositories.json` is absent. This evidence defect is disclosed. A subsequent native Node inventory found the 11 central repositories created after preregistration; `retained-repo-inventory.json` records their paths and times. The two relevant repositories are copied here. All original retained repositories remain in the OS temporary directory.

## Side-file observation

`side-trace/` contains one subsequent preregistered run of a private copy of the fixed package. Only the two generated files listed in its preregistration changed, as shown by the two observation diffs. It recorded 3317 per-boundary side-file events and passed 19/19. Its 64MiB+17 path showed every parent write, every worker source byte, every target native write, and EOF in full. It is a positive observation only. Synchronous logging changes timing and file-descriptor use and can mask the failure. It is not a repair, and it does not locate where the uninstrumented run lost the tail.

The red alone does not uniquely attribute the missing bytes to the first native stdin hop, the worker source iterator, or the second native stdin hop. No precise lower-layer cause is claimed by this archive.

## Portable physical verification

After extraction, from this directory, native Node can read the actual retained Git object again. This verifies the archived red object; it does not rerun product acceptance:

```sh
node probes/d2-cold-object-compare.mjs repositories/wxs-binary-git-0GKk94 42ba1c977089a5c41722faca6d3f05b150ebc84b retained-red/input-67108881.bin /private/tmp/d2-archived-actual.bin /private/tmp/d2-archived-cold.json
shasum -a 256 -c MANIFEST.sha256
```

The original full-sequence commands remain in their preregistrations. Their fixture import paths are preserved as raw provenance and require the original fixed installation; they are not advertised as portable scripts. The included native cold-reader probe is portable on a host with Node and `/usr/bin/git`.

The older original 32MiB+17 formal failure and bounded isolated green replays are archived separately as `D2-LAST17-661-INVESTIGATION.tgz`, SHA256 `06f29df82cdf7a1229404aacb99e09ff4168c4213fb5de491fc9c6fd11e65b3a`. Those isolated passes do not override either full-sequence failure. This archive does not close D2. R12-U1 remains deferred.
