// .build/supervision-70979/Worker.js
import node$003Aprocess2 from "node:process";

// .build/supervision-70979/native-process/BunProcess.js
import { Readable, Writable } from "node:stream";
import * as node$003Afs from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { EventEmitter } from "node:events";
function output(descriptor) {
  return (() => {
    const sink = globalThis.Bun.file(descriptor).writer({ highWaterMark: 65536 });
    return new Writable({
      highWaterMark: 65536,
      write(bytes, _encoding, callback) {
        Promise.resolve().then(() => sink.write(bytes)).then(async (count) => {
          if (count !== bytes.length) throw Object.assign(new Error("Incomplete output forwarding write"), { code: "ERR_STREAM_DESTROYED" });
          await sink.flush();
          callback();
        }).catch(callback);
      }
    });
  })();
}
function spawn(file, arguments$, options) {
  const outputs = (() => {
    const files = node$003Afs;
    const directory = files.mkdtempSync(join(tmpdir(), "wanxiangli-pipes-"));
    const paths = [directory + "/stdout", directory + "/stderr"];
    const descriptors = /* @__PURE__ */ new Set();
    const outputs2 = [];
    const reader = (descriptor) => {
      let pending = null;
      let immediate = false;
      let idleDelay = 0;
      let buffer;
      const receive = () => {
        if (stream.destroyed) return;
        buffer ??= Buffer.allocUnsafe(65536);
        let count;
        try {
          count = files.readSync(descriptor, buffer, 0, buffer.length, null);
        } catch (error) {
          if (error.code === "EAGAIN" || error.code === "EWOULDBLOCK") {
            const retry = () => {
              pending = null;
              receive();
            };
            immediate = idleDelay === 0;
            pending = immediate ? setImmediate(retry) : setTimeout(retry, idleDelay);
            idleDelay = idleDelay === 0 ? 1 : Math.min(5, idleDelay * 2);
          } else {
            stream.destroy(error);
          }
          return;
        }
        idleDelay = 0;
        if (count === 0) stream.push(null);
        else stream.push(Buffer.from(buffer.subarray(0, count)));
      };
      const stream = new Readable({
        highWaterMark: 65536,
        read() {
          if (pending === null) receive();
        },
        destroy(error, callback) {
          if (immediate) clearImmediate(pending);
          else clearTimeout(pending);
          pending = null;
          buffer = void 0;
          const owned = descriptor;
          descriptor = -1;
          try {
            files.closeSync(owned);
            callback(error);
          } catch (closeError) {
            callback(error ?? closeError);
          }
        }
      });
      return stream;
    };
    try {
      const created = globalThis.Bun.spawnSync(["/usr/bin/mkfifo", ...paths], {
        cwd: directory,
        env: {},
        stdin: "ignore",
        stdout: "ignore",
        stderr: "pipe"
      });
      if (created.exitCode !== 0) throw Object.assign(new Error(new TextDecoder().decode(created.stderr) || "Could not create output pipes"), { code: "PIPE_SETUP_FAILED" });
      const pipes = paths.map((path) => {
        const read = files.openSync(path, files.constants.O_RDONLY | files.constants.O_NONBLOCK);
        descriptors.add(read);
        const write = files.openSync(path, files.constants.O_WRONLY);
        descriptors.add(write);
        return { read, write };
      });
      for (const path of paths) files.unlinkSync(path);
      files.rmdirSync(directory);
      for (const pipe of pipes) {
        outputs2.push({ readable: reader(pipe.read), writer: pipe.write });
        descriptors.delete(pipe.read);
      }
      return outputs2;
    } catch (error) {
      let cleanupFailure;
      for (const output2 of outputs2) {
        output2.readable.on("error", () => {
        });
        output2.readable.destroy();
        cleanupFailure ??= output2.readable.errored;
      }
      for (const descriptor of descriptors) {
        try {
          files.closeSync(descriptor);
        } catch (closeError) {
          cleanupFailure ??= closeError;
        }
      }
      try {
        files.rmSync(directory, { recursive: true, force: true });
      } catch (removeError) {
        cleanupFailure ??= removeError;
      }
      if (cleanupFailure) throw Object.assign(new Error(error.message + "; output cleanup was not confirmed: " + cleanupFailure.message), { code: cleanupFailure.code || "PIPE_CLEANUP_FAILED" });
      throw error;
    }
  })();
  return (() => {
    const child = new EventEmitter();
    let startPublished = false;
    let exit;
    let exitPublished = false;
    let closed = false;
    let outputClosed = 0;
    let pendingWrite;
    let nativeProcess;
    const tryClose = () => {
      if (exitPublished && outputClosed === 2 && !closed) {
        closed = true;
        child.emit("close", exit.code, exit.signal);
      }
    };
    const publishExit = () => {
      if (!startPublished || !exit || exitPublished) return;
      exitPublished = true;
      if (pendingWrite) pendingWrite(Object.assign(new Error("Process exited before the input write was acknowledged"), { code: "ERR_STREAM_DESTROYED" }));
      child.stdin.destroy();
      if (exit.error) child.emit("error", exit.error);
      child.emit("exit", exit.code, exit.signal);
      tryClose();
    };
    child.stdout = outputs[0].readable;
    child.stderr = outputs[1].readable;
    for (const output2 of [child.stdout, child.stderr]) output2.once("close", () => {
      outputClosed++;
      tryClose();
    });
    child.stdin = new Writable({
      write(bytes, _encoding, callback) {
        let completed = false;
        const complete = (error) => {
          if (completed) return;
          completed = true;
          pendingWrite = void 0;
          callback(error);
        };
        pendingWrite = complete;
        Promise.resolve().then(() => nativeProcess.stdin.write(bytes)).then(async () => {
          await nativeProcess.stdin.flush();
          setImmediate(() => complete());
        }).catch(complete);
      },
      final(callback) {
        Promise.resolve().then(() => nativeProcess.stdin.end()).then(() => callback(), callback);
      }
    });
    try {
      nativeProcess = globalThis.Bun.spawn([file, ...arguments$], {
        cwd: options.cwd,
        env: options.env,
        detached: options.detached,
        stdin: "pipe",
        stdout: outputs[0].writer,
        stderr: outputs[1].writer,
        onExit(_process, code, signal, error) {
          exit = { code: code ?? null, signal: signal ?? null, error };
          publishExit();
        }
      });
    } catch (error) {
      child.stdin.destroy();
      let cleanupFailure;
      for (const output2 of outputs) {
        output2.readable.on("error", () => {
        });
        output2.readable.destroy();
        cleanupFailure ??= output2.readable.errored;
        try {
          node$003Afs.closeSync(output2.writer);
        } catch (closeError) {
          cleanupFailure ??= closeError;
        }
      }
      if (cleanupFailure) throw Object.assign(new Error(error.message + "; output cleanup was not confirmed: " + cleanupFailure.message), { code: cleanupFailure.code || "PIPE_CLEANUP_FAILED" });
      throw error;
    }
    child.pid = nativeProcess.pid;
    let closeFailure;
    for (const output2 of outputs) {
      try {
        node$003Afs.closeSync(output2.writer);
      } catch (error) {
        closeFailure ??= error;
      }
    }
    queueMicrotask(() => {
      startPublished = true;
      child.emit("spawn");
      if (closeFailure) {
        child.emit("error", closeFailure);
        child.stdout.destroy(closeFailure);
        child.stderr.destroy(closeFailure);
      }
      publishExit();
    });
    return child;
  })();
}

// .build/supervision-70979/Native.js
import { spawn as spawn_1 } from "node:child_process";
import node$003Aprocess from "node:process";
import { Transform } from "node:stream";

// node_modules/@fable-org/fable-library-js/Util.js
var DateTimeKind = {
  Unspecified: 0,
  Utc: 1,
  Local: 2
};
var Exception = class {
  constructor(msg, innerException) {
    this.message = msg ?? "";
    this.innerException = innerException;
  }
  toString() {
    return this.message;
  }
};
function isArrayLike(x) {
  return Array.isArray(x) || ArrayBuffer.isView(x);
}
function isEnumerable(x) {
  return x != null && typeof x.GetEnumerator === "function";
}
function isComparable(x) {
  return x != null && typeof x.CompareTo === "function";
}
function isEquatable(x) {
  return x != null && typeof x.Equals === "function";
}
function isHashable(x) {
  return x != null && typeof x.GetHashCode === "function";
}
function isDisposable(x) {
  return x != null && typeof x.Dispose === "function";
}
function disposeSafe(x) {
  if (isDisposable(x)) {
    x.Dispose();
  }
}
function defaultOf() {
  return null;
}
function sameConstructor(x, y) {
  return Object.getPrototypeOf(x)?.constructor === Object.getPrototypeOf(y)?.constructor;
}
var Enumerator = class {
  constructor(iter) {
    this.current = defaultOf();
    this.iter = iter;
  }
  ["System.Collections.Generic.IEnumerator`1.get_Current"]() {
    return this.current;
  }
  ["System.Collections.IEnumerator.get_Current"]() {
    return this.current;
  }
  ["System.Collections.IEnumerator.MoveNext"]() {
    const cur = this.iter.next();
    this.current = cur.value;
    return !cur.done;
  }
  ["System.Collections.IEnumerator.Reset"]() {
    throw new Exception("JS iterators cannot be reset");
  }
  Dispose() {
    return;
  }
};
function getEnumerator(e) {
  if (isEnumerable(e)) {
    return e.GetEnumerator();
  } else {
    return new Enumerator(e[Symbol.iterator]());
  }
}
function toIterator(en) {
  return {
    next() {
      const hasNext = en["System.Collections.IEnumerator.MoveNext"]();
      const current = hasNext ? en["System.Collections.Generic.IEnumerator`1.get_Current"]() : void 0;
      return { done: !hasNext, value: current };
    }
  };
}
function dateOffset(date) {
  const date1 = date;
  return typeof date1.offset === "number" ? date1.offset : date.kind === DateTimeKind.Utc ? 0 : date.getTimezoneOffset() * -6e4;
}
function int32ToString(i, radix) {
  i = i < 0 && radix != null && radix !== 10 ? 4294967295 + i + 1 : i;
  return i.toString(radix);
}
var ObjectRef = class _ObjectRef {
  static id(o) {
    if (!_ObjectRef.idMap.has(o)) {
      _ObjectRef.idMap.set(o, ++_ObjectRef.count);
    }
    return _ObjectRef.idMap.get(o);
  }
};
ObjectRef.idMap = /* @__PURE__ */ new WeakMap();
ObjectRef.count = 0;
function stringHash(s) {
  let i = 0;
  let h = 5381;
  const len = s.length;
  while (i < len) {
    h = h * 33 ^ s.charCodeAt(i++);
  }
  return h;
}
function numberHash(x) {
  return x * 2654435761 | 0;
}
function bigintHash(x) {
  return stringHash(x.toString(32));
}
function combineHashCodes(hashes) {
  let h1 = 0;
  const len = hashes.length;
  for (let i = 0; i < len; i++) {
    const h2 = hashes[i];
    h1 = (h1 << 5) + h1 ^ h2;
  }
  return h1;
}
function dateHash(x) {
  return x.getTime();
}
function arrayHash(x) {
  const len = x.length;
  const hashes = new Array(len);
  for (let i = 0; i < len; i++) {
    hashes[i] = structuralHash(x[i]);
  }
  return combineHashCodes(hashes);
}
function structuralHash(x) {
  if (x == null) {
    return 0;
  }
  switch (typeof x) {
    case "boolean":
      return x ? 1 : 0;
    case "number":
      return numberHash(x);
    case "bigint":
      return bigintHash(x);
    case "string":
      return stringHash(x);
    default: {
      if (isHashable(x)) {
        return x.GetHashCode();
      } else if (isArrayLike(x)) {
        return arrayHash(x);
      } else if (x instanceof Date) {
        return dateHash(x);
      } else if (Object.getPrototypeOf(x)?.constructor === Object) {
        const hashes = Object.values(x).map((v) => structuralHash(v));
        return combineHashCodes(hashes);
      } else {
        return numberHash(ObjectRef.id(x));
      }
    }
  }
}
function equalArraysWith(x, y, eq) {
  if (x == null) {
    return y == null;
  }
  if (y == null) {
    return false;
  }
  if (x.length !== y.length) {
    return false;
  }
  for (let i = 0; i < x.length; i++) {
    if (!eq(x[i], y[i])) {
      return false;
    }
  }
  return true;
}
function equalArrays(x, y) {
  return equalArraysWith(x, y, equals);
}
function equalObjects(x, y) {
  const xKeys = Object.keys(x);
  const yKeys = Object.keys(y);
  if (xKeys.length !== yKeys.length) {
    return false;
  }
  xKeys.sort();
  yKeys.sort();
  for (let i = 0; i < xKeys.length; i++) {
    if (xKeys[i] !== yKeys[i] || !equals(x[xKeys[i]], y[yKeys[i]])) {
      return false;
    }
  }
  return true;
}
function equals(x, y) {
  if (x === y) {
    return true;
  } else if (x == null) {
    return y == null;
  } else if (y == null) {
    return false;
  } else if (isEquatable(x)) {
    return x.Equals(y);
  } else if (isArrayLike(x)) {
    return isArrayLike(y) && equalArrays(x, y);
  } else if (typeof x !== "object") {
    return false;
  } else if (x instanceof Date) {
    return y instanceof Date && compareDates(x, y) === 0;
  } else {
    return Object.getPrototypeOf(x)?.constructor === Object && equalObjects(x, y);
  }
}
function compareDates(x, y) {
  let xtime;
  let ytime;
  if ("offset" in x && "offset" in y) {
    xtime = x.getTime();
    ytime = y.getTime();
  } else {
    xtime = x.getTime() + dateOffset(x);
    ytime = y.getTime() + dateOffset(y);
  }
  return xtime === ytime ? 0 : xtime < ytime ? -1 : 1;
}
function comparePrimitives(x, y) {
  if (x === y) {
    return 0;
  }
  if (x < y) {
    return -1;
  }
  if (x > y) {
    return 1;
  }
  return Number.isNaN(x) ? Number.isNaN(y) ? 0 : -1 : 1;
}
function compareArraysWith(x, y, comp) {
  if (x == null) {
    return y == null ? 0 : 1;
  }
  if (y == null) {
    return -1;
  }
  if (x.length !== y.length) {
    return x.length < y.length ? -1 : 1;
  }
  for (let i = 0, j = 0; i < x.length; i++) {
    j = comp(x[i], y[i]);
    if (j !== 0) {
      return j;
    }
  }
  return 0;
}
function compareArrays(x, y) {
  return compareArraysWith(x, y, compare);
}
function compareObjects(x, y) {
  const xKeys = Object.keys(x);
  const yKeys = Object.keys(y);
  if (xKeys.length !== yKeys.length) {
    return xKeys.length < yKeys.length ? -1 : 1;
  }
  xKeys.sort();
  yKeys.sort();
  for (let i = 0, j = 0; i < xKeys.length; i++) {
    const key = xKeys[i];
    if (key !== yKeys[i]) {
      return key < yKeys[i] ? -1 : 1;
    } else {
      j = compare(x[key], y[key]);
      if (j !== 0) {
        return j;
      }
    }
  }
  return 0;
}
function compare(x, y) {
  if (x === y) {
    return 0;
  } else if (x == null) {
    return y == null ? 0 : -1;
  } else if (y == null) {
    return 1;
  } else if (isComparable(x)) {
    return x.CompareTo(y);
  } else if (isArrayLike(x)) {
    return isArrayLike(y) ? compareArrays(x, y) : -1;
  } else if (typeof x !== "object") {
    return comparePrimitives(x, y);
  } else if (x instanceof Date) {
    return y instanceof Date ? compareDates(x, y) : -1;
  } else {
    return Object.getPrototypeOf(x)?.constructor === Object ? compareObjects(x, y) : -1;
  }
}
function createObj(fields) {
  const obj = {};
  for (const kv of fields) {
    obj[kv[0]] = kv[1];
  }
  return obj;
}
var curried = /* @__PURE__ */ new WeakMap();
function curry2(f) {
  return curried.get(f) ?? ((a1) => (a2) => f(a1, a2));
}

// node_modules/@fable-org/fable-library-js/Native.js
function Helpers_allocateArrayFromCons(cons, len) {
  if (cons == null) {
    return new Array(len);
  } else {
    const cons_1 = cons;
    if (typeof cons_1 === "function") {
      return new cons_1(len);
    } else {
      return new Array(len);
    }
  }
}

// node_modules/@fable-org/fable-library-js/Option.js
var Some = class _Some {
  constructor(value2) {
    this.value = value2;
  }
  toJSON() {
    return this.value;
  }
  // Don't add "Some" for consistency with erased options
  toString() {
    return String(this.value);
  }
  GetHashCode() {
    return structuralHash(this.value);
  }
  Equals(other) {
    if (other == null) {
      return false;
    } else {
      return equals(this.value, other instanceof _Some ? other.value : other);
    }
  }
  CompareTo(other) {
    if (other == null) {
      return 1;
    } else {
      return compare(this.value, other instanceof _Some ? other.value : other);
    }
  }
};
function value(x) {
  if (x == null) {
    throw new Exception("Option has no value");
  } else {
    return x instanceof Some ? x.value : x;
  }
}

// node_modules/@fable-org/fable-library-js/Types.js
function seqToString(self) {
  let count = 0;
  let str = "[";
  for (const x of self) {
    if (count === 0) {
      str += toStringQuoted(x);
    } else if (count === 100) {
      str += "; ...";
      break;
    } else {
      str += "; " + toStringQuoted(x);
    }
    count++;
  }
  return str + "]";
}
function toStringQuoted(x, callStack = 0) {
  return typeof x === "string" ? '"' + x + '"' : toString(x, callStack);
}
function toString(x, callStack = 0) {
  if (x != null && typeof x === "object") {
    if (typeof x.toString === "function" && x.toString !== Object.prototype.toString) {
      return x.toString();
    } else if (Symbol.iterator in x) {
      return seqToString(x);
    } else {
      const cons = Object.getPrototypeOf(x)?.constructor;
      return cons === Object && callStack < 10 ? "{ " + Object.entries(x).map(([k, v]) => k + " = " + toStringQuoted(v, callStack + 1)).join("\n  ") + " }" : cons?.name ?? "";
    }
  }
  return String(x);
}
function unionToString(name, fields) {
  if (fields.length === 0) {
    return name;
  } else {
    let fieldStr;
    let withParens = true;
    if (fields.length === 1) {
      fieldStr = toStringQuoted(fields[0]);
      withParens = fieldStr.indexOf(" ") >= 0;
    } else {
      fieldStr = fields.map((x) => toStringQuoted(x)).join(", ");
    }
    return name + (withParens ? " (" : " ") + fieldStr + (withParens ? ")" : "");
  }
}
var Union = class {
  get name() {
    return this.cases()[this.tag];
  }
  toJSON() {
    return this.fields.length === 0 ? this.name : [this.name].concat(this.fields);
  }
  toString() {
    return unionToString(this.name, this.fields);
  }
  GetHashCode() {
    const hashes = this.fields.map((x) => structuralHash(x));
    hashes.splice(0, 0, numberHash(this.tag));
    return combineHashCodes(hashes);
  }
  Equals(other) {
    if (this === other) {
      return true;
    } else if (!sameConstructor(this, other)) {
      return false;
    } else if (this.tag === other.tag) {
      return equalArrays(this.fields, other.fields);
    } else {
      return false;
    }
  }
  CompareTo(other) {
    if (this === other) {
      return 0;
    } else if (!sameConstructor(this, other)) {
      return -1;
    } else if (this.tag === other.tag) {
      return compareArrays(this.fields, other.fields);
    } else {
      return this.tag < other.tag ? -1 : 1;
    }
  }
};
function recordToJSON(self) {
  const o = {};
  const keys = Object.keys(self);
  for (let i = 0; i < keys.length; i++) {
    o[keys[i]] = self[keys[i]];
  }
  return o;
}
function recordToString(self) {
  return "{ " + Object.entries(self).map(([k, v]) => k + " = " + toStringQuoted(v)).join("\n  ") + " }";
}
function recordGetHashCode(self) {
  const hashes = Object.values(self).map((v) => structuralHash(v));
  return combineHashCodes(hashes);
}
function recordEquals(self, other) {
  if (self === other) {
    return true;
  } else if (!sameConstructor(self, other)) {
    return false;
  } else {
    const thisNames = Object.keys(self);
    for (let i = 0; i < thisNames.length; i++) {
      if (!equals(self[thisNames[i]], other[thisNames[i]])) {
        return false;
      }
    }
    return true;
  }
}
function recordCompareTo(self, other) {
  if (self === other) {
    return 0;
  } else if (!sameConstructor(self, other)) {
    return -1;
  } else {
    const thisNames = Object.keys(self);
    for (let i = 0; i < thisNames.length; i++) {
      const result = compare(self[thisNames[i]], other[thisNames[i]]);
      if (result !== 0) {
        return result;
      }
    }
    return 0;
  }
}
var Record = class {
  toJSON() {
    return recordToJSON(this);
  }
  toString() {
    return recordToString(this);
  }
  GetHashCode() {
    return recordGetHashCode(this);
  }
  Equals(other) {
    return recordEquals(this, other);
  }
  CompareTo(other) {
    return recordCompareTo(this, other);
  }
};

// node_modules/@fable-org/fable-library-js/Global.js
var SR_inputWasEmpty = "Collection was empty.";

// node_modules/@fable-org/fable-library-js/FSharp.Core.js
function Operators_IsNull(value2) {
  if (equals(value2, defaultOf())) {
    return true;
  } else {
    return false;
  }
}

// node_modules/@fable-org/fable-library-js/Array.js
function fill(target, targetIndex, count, value2) {
  const start = targetIndex | 0;
  return target.fill(value2, start, start + count);
}
function map(f, source, cons) {
  const len = source.length | 0;
  const target = Helpers_allocateArrayFromCons(cons, len);
  for (let i = 0; i <= len - 1; i++) {
    setItem(target, i, f(item(i, source)));
  }
  return target;
}
function initialize(count, initializer, cons) {
  if (count < 0) {
    throw new Exception("The input must be non-negative (Parameter 'count')");
  }
  const result = Helpers_allocateArrayFromCons(cons, count);
  for (let i = 0; i <= count - 1; i++) {
    setItem(result, i, initializer(i));
  }
  return result;
}
function sort(xs, comparer) {
  const xs_1 = xs.slice();
  xs_1.sort((x, y) => comparer.Compare(x, y) | 0);
  return xs_1;
}
function equalsWith(equals2, source1, source2) {
  if (Operators_IsNull(source1)) {
    if (Operators_IsNull(source2)) {
      return true;
    } else {
      return false;
    }
  } else if (Operators_IsNull(source2)) {
    return false;
  } else {
    let i = 0;
    let result = true;
    const length1 = source1.length | 0;
    const length2 = source2.length | 0;
    if (length1 > length2) {
      return false;
    } else if (length1 < length2) {
      return false;
    } else {
      while (i < length1 && result) {
        result = equals2(item(i, source1), item(i, source2));
        i = i + 1 | 0;
      }
      return result;
    }
  }
}
function item(index, array) {
  if (index < 0 ? true : index >= array.length) {
    throw new Exception("Index was outside the bounds of the array. (Parameter 'index')");
  } else {
    return array[index];
  }
}
function setItem(array, index, value2) {
  if (index < 0 ? true : index >= array.length) {
    throw new Exception("Index was outside the bounds of the array. (Parameter 'index')");
  } else {
    array[index] = value2;
  }
}

// node_modules/@fable-org/fable-library-js/Seq.js
function toArray2(xs) {
  if (xs instanceof FSharpList) {
    const a = xs;
    return toArray(a);
  } else {
    return Array.from(xs);
  }
}

// node_modules/@fable-org/fable-library-js/List.js
var FSharpList = class _FSharpList extends Record {
  constructor(head, tail) {
    super();
    this.head = head;
    this.tail = tail;
  }
  toString() {
    const xs = this;
    let result = "[";
    let first = true;
    const enumerator = getEnumerator(xs);
    try {
      while (enumerator["System.Collections.IEnumerator.MoveNext"]()) {
        let x = void 0, matchValue = void 0, s = void 0;
        const x_1 = enumerator["System.Collections.Generic.IEnumerator`1.get_Current"]();
        result = (first ? result : result + "; ") + (x = x_1, matchValue = x, typeof matchValue === "string" ? (s = matchValue, '"' + s + '"') : toString(x));
        first = false;
      }
    } finally {
      disposeSafe(enumerator);
    }
    return result + "]";
  }
  Equals(other) {
    const xs = this;
    if (xs === other) {
      return true;
    } else if (other instanceof _FSharpList) {
      const ys = other;
      const loop = (xs_1_mut, ys_1_mut) => {
        loop: while (true) {
          const xs_1 = xs_1_mut, ys_1 = ys_1_mut;
          const matchValue = xs_1.tail;
          const matchValue_1 = ys_1.tail;
          if (matchValue != null) {
            if (matchValue_1 != null) {
              const xt = value(matchValue);
              const yt = value(matchValue_1);
              if (equals(xs_1.head, ys_1.head)) {
                xs_1_mut = xt;
                ys_1_mut = yt;
                continue loop;
              } else {
                return false;
              }
            } else {
              return false;
            }
          } else if (matchValue_1 != null) {
            return false;
          } else {
            return true;
          }
          break;
        }
      };
      return loop(xs, ys);
    } else {
      return false;
    }
  }
  GetHashCode() {
    const xs = this;
    const loop = (i_mut, h_mut, xs_1_mut) => {
      loop: while (true) {
        const i = i_mut, h = h_mut, xs_1 = xs_1_mut;
        const matchValue = xs_1.tail;
        if (matchValue != null) {
          const t = value(matchValue);
          if (i > 18) {
            return h | 0;
          } else {
            i_mut = i + 1;
            h_mut = (h << 1) + structuralHash(xs_1.head) + 631 * i;
            xs_1_mut = t;
            continue loop;
          }
        } else {
          return h | 0;
        }
        break;
      }
    };
    return loop(0, 0, xs) | 0;
  }
  toJSON() {
    const this$ = this;
    return Array.from(this$);
  }
  CompareTo(other) {
    const xs = this;
    if (other instanceof _FSharpList) {
      const ys = other;
      const loop = (xs_1_mut, ys_1_mut) => {
        loop: while (true) {
          const xs_1 = xs_1_mut, ys_1 = ys_1_mut;
          const matchValue = xs_1.tail;
          const matchValue_1 = ys_1.tail;
          if (matchValue != null) {
            if (matchValue_1 != null) {
              const xt = value(matchValue);
              const yt = value(matchValue_1);
              const c = compare(xs_1.head, ys_1.head) | 0;
              if (c === 0) {
                xs_1_mut = xt;
                ys_1_mut = yt;
                continue loop;
              } else {
                return c | 0;
              }
            } else {
              return 1;
            }
          } else if (matchValue_1 != null) {
            return -1;
          } else {
            return 0;
          }
          break;
        }
      };
      return loop(xs, ys) | 0;
    } else {
      return 1;
    }
  }
  GetEnumerator() {
    const xs = this;
    return ListEnumerator$1_$ctor_3002E699(xs);
  }
  [Symbol.iterator]() {
    return toIterator(getEnumerator(this));
  }
  "System.Collections.IEnumerable.GetEnumerator"() {
    const xs = this;
    return getEnumerator(xs);
  }
};
var ListEnumerator$1 = class {
  constructor(xs) {
    this.xs = xs;
    this.it = this.xs;
    this.current = defaultOf();
  }
  "System.Collections.Generic.IEnumerator`1.get_Current"() {
    const _ = this;
    return _.current;
  }
  "System.Collections.IEnumerator.get_Current"() {
    const _ = this;
    return _.current;
  }
  "System.Collections.IEnumerator.MoveNext"() {
    const _ = this;
    const matchValue = _.it.tail;
    if (matchValue != null) {
      const t = value(matchValue);
      _.current = _.it.head;
      _.it = t;
      return true;
    } else {
      return false;
    }
  }
  "System.Collections.IEnumerator.Reset"() {
    const _ = this;
    _.it = _.xs;
    _.current = defaultOf();
  }
  Dispose() {
  }
};
function ListEnumerator$1_$ctor_3002E699(xs) {
  return new ListEnumerator$1(xs);
}
function FSharpList_get_Empty() {
  return new FSharpList(defaultOf(), void 0);
}
function FSharpList_Cons_305B8EAC(x, xs) {
  return new FSharpList(x, xs);
}
function FSharpList__get_IsEmpty(xs) {
  return xs.tail == null;
}
function FSharpList__get_Length(xs) {
  const loop = (i_mut, xs_1_mut) => {
    loop: while (true) {
      const i = i_mut, xs_1 = xs_1_mut;
      const matchValue = xs_1.tail;
      if (matchValue != null) {
        i_mut = i + 1;
        xs_1_mut = value(matchValue);
        continue loop;
      } else {
        return i | 0;
      }
      break;
    }
  };
  return loop(0, xs) | 0;
}
function FSharpList__get_Head(xs) {
  const matchValue = xs.tail;
  if (matchValue != null) {
    return xs.head;
  } else {
    throw new Exception(SR_inputWasEmpty + " (Parameter 'list')");
  }
}
function FSharpList__get_Tail(xs) {
  const matchValue = xs.tail;
  if (matchValue != null) {
    return value(matchValue);
  } else {
    throw new Exception(SR_inputWasEmpty + " (Parameter 'list')");
  }
}
function singleton(x) {
  return FSharpList_Cons_305B8EAC(x, FSharpList_get_Empty());
}
function toArray(xs) {
  const len = FSharpList__get_Length(xs) | 0;
  const res = fill(new Array(len), 0, len, null);
  const loop = (i_mut, xs_1_mut) => {
    loop: while (true) {
      const i = i_mut, xs_1 = xs_1_mut;
      if (!FSharpList__get_IsEmpty(xs_1)) {
        setItem(res, i, FSharpList__get_Head(xs_1));
        i_mut = i + 1;
        xs_1_mut = FSharpList__get_Tail(xs_1);
        continue loop;
      }
      break;
    }
  };
  loop(0, xs);
  return res;
}
function ofArrayWithTail(xs, tail_1) {
  let res = tail_1;
  for (let i = xs.length - 1; i >= 0; i--) {
    res = FSharpList_Cons_305B8EAC(item(i, xs), res);
  }
  return res;
}
function ofArray(xs) {
  return ofArrayWithTail(xs, FSharpList_get_Empty());
}

// .build/supervision-70979/Native.js
import * as node$003Afs2 from "node:fs";
import { isAbsolute, join as join2 } from "node:path";
import { tmpdir as tmpdir2 } from "node:os";
function Native_spawn(file, arguments$, options) {
  if (typeof globalThis.Bun !== "undefined") {
    return spawn(file, arguments$, options);
  } else {
    return spawn_1(file, arguments$, options);
  }
}
function Native_output(channel) {
  if (typeof globalThis.Bun !== "undefined") {
    return output(channel === "stdout" ? 1 : 2);
  } else {
    return node$003Aprocess[channel];
  }
}
function Native_forward(source, target, count, ended, failed) {
  (() => {
    const counted = new Transform({ transform(bytes, _encoding, callback) {
      try {
        count(bytes.length);
        callback(null, bytes);
      } catch (error) {
        callback(error);
      }
    } });
    counted.on("error", failed);
    counted.once("end", ended);
    source.pipe(counted).pipe(target, { end: false });
  })();
}
function Native_require(condition, message) {
  if (!condition) {
    throw new Exception(message);
  }
}
function Native_get(value2, name) {
  return value2[name];
}
function Native_objectOf(fields) {
  return createObj(fields);
}
function Native_value(source, name) {
  const property = Object.getOwnPropertyDescriptor(source, name);
  Native_require(property != null && Object.prototype.hasOwnProperty.call(property, "value"), "Expected an own data field: " + name);
  return Native_get(property, "value");
}
function Native_fields(expected, source) {
  Native_require(source !== null && typeof source === "object" && (Object.getPrototypeOf(source) === Object.prototype || Object.getPrototypeOf(source) === null) && Object.getOwnPropertySymbols(source).length === 0, "Expected a plain data object");
  Native_require(equalsWith((x_2, y_2) => x_2 === y_2, sort(Object.getOwnPropertyNames(source), {
    Compare: (x, y) => comparePrimitives(x, y) | 0
  }), sort(toArray(expected), {
    Compare: (x_1, y_1) => comparePrimitives(x_1, y_1) | 0
  })), "Unexpected or missing fields");
  const enumerator = getEnumerator(expected);
  try {
    while (enumerator["System.Collections.IEnumerator.MoveNext"]()) {
      Native_value(source, enumerator["System.Collections.Generic.IEnumerator`1.get_Current"]());
    }
  } finally {
    disposeSafe(enumerator);
  }
}
function Native_text(allowEmpty, source) {
  Native_require(typeof source === "string" && source.isWellFormed() && !source.includes("\0"), "Expected valid text without NUL");
  const result = source;
  Native_require(allowEmpty ? true : result.length > 0, "Text must not be empty");
  return result;
}
function Native_integer(maximum, source) {
  Native_require(Number.isSafeInteger(source) && source >= 0 && source <= maximum, "Expected a non-negative safe integer within the limit");
  return source;
}
function Native_failure(operation, error) {
  const code = Native_get(error, "code");
  const message = Native_get(error, "message");
  return Native_objectOf([["operation", operation], ["code", code == null ? defaultOf() : code], ["message", message == null ? "Native operation failed" : toString(message)]]);
}
function Native_problem(operation, code, message) {
  return Native_objectOf([["operation", operation], ["code", code], ["message", message]]);
}
function Native_exists(path) {
  return node$003Afs2.existsSync(path);
}
function Native_read(path) {
  return JSON.parse(node$003Afs2.readFileSync(path, "utf8"));
}
function Native_publish(directory, name, value2) {
  const pending = join2(directory, name + ".pending");
  node$003Afs2.writeFileSync(pending, JSON.stringify(value2), Native_objectOf([["mode", 384]]));
  node$003Afs2.renameSync(pending, join2(directory, name));
}
function Native_remove(directory) {
  node$003Afs2.rmSync(directory, Native_objectOf([["recursive", true], ["force", true]]));
}
function Native_createDirectory() {
  const directory = node$003Afs2.mkdtempSync(join2(tmpdir2(), "wanxiangli-supervision-"));
  node$003Afs2.chmodSync(directory, 448);
  return directory;
}
function Options_read(input) {
  Native_fields(ofArray(["executable", "args", "cwd", "env", "tailBytes", "maxWriteBytes"]), input);
  const enumerator = getEnumerator(["executable", "cwd"]);
  try {
    while (enumerator["System.Collections.IEnumerator.MoveNext"]()) {
      const name = enumerator["System.Collections.Generic.IEnumerator`1.get_Current"]();
      Native_require(isAbsolute(Native_text(false, Native_value(input, name))), name + " must be absolute");
    }
  } finally {
    disposeSafe(enumerator);
  }
  const arguments$ = Native_value(input, "args");
  Native_require(Array.isArray(arguments$) && Object.getOwnPropertySymbols(arguments$).length === 0, "args must be an array of data strings");
  const count = arguments$.length | 0;
  Native_require(Object.getOwnPropertyNames(arguments$).length === count + 1, "args contains extra properties or holes");
  const arguments$_1 = initialize(count, (index) => Native_text(true, Native_value(arguments$, int32ToString(index))));
  const environment = Native_value(input, "env");
  Native_require(environment !== null && typeof environment === "object" && (Object.getPrototypeOf(environment) === Object.prototype || Object.getPrototypeOf(environment) === null) && Object.getOwnPropertySymbols(environment).length === 0, "env must be a plain data object");
  const entries = map((name_1) => {
    Native_text(false, name_1);
    Native_require(!(name_1.indexOf("=") >= 0), "Environment name contains equals");
    return [name_1, Native_text(true, Native_value(environment, name_1))];
  }, Object.getOwnPropertyNames(environment));
  const tail = Native_integer(16777216, Native_value(input, "tailBytes"));
  const write = Native_integer(16777216, Native_value(input, "maxWriteBytes"));
  Native_require(write > 0, "maxWriteBytes must be positive");
  const platform = node$003Aprocess.platform;
  Native_require(platform === "linux" ? true : platform === "darwin", "POSIX process groups are required");
  return Native_objectOf([["executable", Native_value(input, "executable")], ["args", arguments$_1], ["cwd", Native_value(input, "cwd")], ["env", Object.fromEntries(entries)], ["tailBytes", tail], ["maxWriteBytes", write]]);
}

// .build/supervision-70979/Worker.js
import { join as join3 } from "node:path";

// node_modules/@fable-org/fable-library-js/Result.js
var FSharpResult$2 = class extends Union {
  constructor(tag, fields) {
    super();
    this.tag = tag;
    this.fields = fields;
  }
  cases() {
    return ["Ok", "Error"];
  }
};

// .build/supervision-70979/Worker.js
import { fileURLToPath } from "node:url";
function run(directory) {
  let failed = false;
  let targetClosed = false;
  let stdoutForwarded = false;
  let stderrForwarded = false;
  let stdoutBytes = 0;
  let stderrBytes = 0;
  let publishedClose = false;
  const publish = (name, value2) => {
    try {
      Native_publish(directory, name, value2);
    } catch (matchValue) {
      node$003Aprocess2.kill(-node$003Aprocess2.pid, "SIGKILL");
    }
  };
  const fault = (operation, error) => {
    if (!failed) {
      failed = true;
      publish("fault", Native_failure(operation, error));
    }
  };
  const finish = () => {
    if (!publishedClose && !failed && targetClosed && stdoutForwarded && stderrForwarded) {
      publishedClose = true;
      publish("closed", Native_objectOf([["closed", true], ["stdoutBytes", stdoutBytes], ["stderrBytes", stderrBytes]]));
    }
  };
  const enumerator = getEnumerator(["SIGTERM", "SIGINT", "SIGHUP"]);
  try {
    while (enumerator["System.Collections.IEnumerator.MoveNext"]()) {
      const signal = enumerator["System.Collections.Generic.IEnumerator`1.get_Current"]();
      node$003Aprocess2.on(signal, ((value_1) => {
      }));
    }
  } finally {
    disposeSafe(enumerator);
  }
  setInterval((() => {
  }), 6e4);
  try {
    const options = Options_read(Native_read(join3(directory, "request")));
    let target;
    try {
      target = new FSharpResult$2(
        /* Ok */
        0,
        [Native_spawn(Native_get(options, "executable"), Native_get(options, "args"), Native_objectOf([["cwd", Native_get(options, "cwd")], ["env", Native_get(options, "env")], ["shell", false], ["detached", false], ["stdio", ["pipe", "pipe", "pipe"]]]))]
      );
    } catch (error_1) {
      target = new FSharpResult$2(
        /* Error */
        1,
        [error_1]
      );
    }
    if (target.tag === 0) {
      const target_1 = target.fields[0];
      let started = false;
      target_1.on("spawn", ((_arg) => {
        started = true;
        publish("started", Native_objectOf([["pid", Native_get(target_1, "pid")]]));
      }));
      target_1.on("error", ((error_3) => {
        if (started) {
          fault("target", error_3);
        } else {
          publish("failed", Native_failure("spawn", error_3));
        }
      }));
      target_1.on("exit", ((code, signal_1) => {
        publish("exit", Native_objectOf([["code", code], ["signal", signal_1]]));
      }));
      target_1.on("close", ((_arg_1, _arg_2) => {
        targetClosed = true;
        finish();
      }));
      const enumerator_1 = getEnumerator(["stdout", "stderr"]);
      try {
        while (enumerator_1["System.Collections.IEnumerator.MoveNext"]()) {
          const channel = enumerator_1["System.Collections.Generic.IEnumerator`1.get_Current"]();
          const output2 = Native_output(channel);
          const source = Native_get(target_1, channel);
          source.on("error", curry2(fault)(channel));
          output2.on("error", curry2(fault)(channel));
          Native_forward(source, output2, (length2) => {
            if (channel === "stdout") {
              stdoutBytes = stdoutBytes + length2;
            } else {
              stderrBytes = stderrBytes + length2;
            }
          }, () => {
            if (channel === "stdout") {
              stdoutForwarded = true;
            } else {
              stderrForwarded = true;
            }
            finish();
          }, curry2(fault)(channel));
        }
      } finally {
        disposeSafe(enumerator_1);
      }
      const input_1 = Native_get(target_1, "stdin");
      input_1.on("error", ((value_4) => {
      }));
      Native_get(node$003Aprocess2, "stdin").on("error", curry2(fault)("stdin"));
      (async () => {
        try {
          for await (const bytes of Native_get(node$003Aprocess2, "stdin").iterator({ destroyOnReturn: false })) {
            const written = await new Promise((resolve) => {
              try {
                input_1.write(bytes, (error) => resolve(!error));
              } catch (_) {
                resolve(false);
              }
            });
            if (!written) return;
          }
        } catch (error) {
          curry2(fault)("stdin")(error);
          return;
        }
        try {
          input_1.end();
        } catch (_) {
        }
      })();
    } else {
      publish("failed", Native_failure("spawn", target.fields[0]));
    }
  } catch (error_4) {
    fault("worker", error_4);
  }
}
function isEntry() {
  const arguments$ = node$003Aprocess2.argv;
  if (arguments$.length === 4 && item(1, arguments$) === fileURLToPath(import.meta.url)) {
    return item(2, arguments$) === "--wanxiangli-supervisor";
  } else {
    return false;
  }
}

// .build/supervision-70979/SupervisedProcess.js
import node$003Aprocess3 from "node:process";
import { fileURLToPath as fileURLToPath2 } from "node:url";
import { tmpdir as tmpdir3 } from "node:os";
import { ProcessSession } from "wanxiangli/process";
import { join as join4 } from "node:path";

// node_modules/@fable-org/fable-library-js/MapUtil.js
function addToDict(dict, k, v) {
  if (dict.has(k)) {
    throw new Exception("An item with the same key has already been added. Key: " + k);
  }
  dict.set(k, v);
}

// .build/supervision-70979/SupervisedProcess.js
if (isEntry()) {
  run(item(3, node$003Aprocess3.argv));
}
function SupervisedProcess(input) {
  const options = Options_read(input);
  const directory = Native_createDirectory();
  let inner;
  try {
    Native_publish(directory, "request", options);
    const workerOptions = Native_objectOf([["executable", Native_get(node$003Aprocess3, "execPath")], ["args", [fileURLToPath2(import.meta.url), "--wanxiangli-supervisor", directory]], ["cwd", tmpdir3()], ["env", Native_objectOf([])], ["tailBytes", Native_get(options, "tailBytes")], ["maxWriteBytes", Native_get(options, "maxWriteBytes")]]);
    inner = new ProcessSession(workerOptions, "Capture");
  } catch (matchValue) {
    Native_remove(directory);
    throw matchValue;
  }
  let busy = false;
  let targetPid = defaultOf();
  let targetExit = defaultOf();
  let failure = defaultOf();
  let startResult = defaultOf();
  let targetClosed = false;
  let targetOutput = void 0;
  let shutdownRequested = false;
  let outputInterrupted = false;
  let controlFailed = false;
  let closed = false;
  let capture = "Open";
  let pollTimer = defaultOf();
  let reportStart = (value_1) => {
  };
  const startup = new Promise((resolve) => {
    reportStart = resolve;
  });
  const waits = /* @__PURE__ */ new Map([]);
  let nextWait = 0;
  const guard = (action) => {
    Native_require(!busy, "SupervisedProcess does not allow reentrant messages");
    busy = true;
    try {
      return action();
    } finally {
      busy = false;
    }
  };
  const remember = (detail) => {
    if (Operators_IsNull(failure)) {
      failure = JSON.parse(JSON.stringify(detail));
    }
  };
  const settleStart = (result) => {
    if (Operators_IsNull(startResult)) {
      startResult = JSON.parse(JSON.stringify(result));
      if (Native_get(result, "kind") === "Failed") {
        capture = "Discarded";
        inner.discardOutput();
      }
      reportStart(JSON.parse(JSON.stringify(result)));
    }
  };
  const snapshot = () => {
    const worker = inner.inspect();
    const workerPhase = worker.phase;
    return Native_objectOf([["phase", closed ? "Closed" : (((targetClosed ? true : !Operators_IsNull(targetExit)) ? true : workerPhase === "Closed") ? true : workerPhase === "Draining") ? "Draining" : Operators_IsNull(targetPid) ? "Starting" : "Running"], ["pid", targetPid], ["exit", Operators_IsNull(targetExit) ? defaultOf() : JSON.parse(JSON.stringify(targetExit))], ["failure", Operators_IsNull(failure) ? defaultOf() : JSON.parse(JSON.stringify(failure))], ["stdin", Native_get(worker, "stdin")], ["stdout", Native_get(worker, "stdout")], ["stderr", Native_get(worker, "stderr")], ["capture", capture], ["supervisor", Native_objectOf([["pid", Native_get(worker, "pid")], ["phase", workerPhase], ["exit", Native_get(worker, "exit")], ["failure", Native_get(worker, "failure")]])]]);
  };
  const shutdown = () => {
    if (!shutdownRequested) {
      const result_1 = inner.signal("SIGKILL");
      const kind = result_1.kind;
      switch (kind) {
        case "Requested": {
          shutdownRequested = true;
          break;
        }
        case "Failed": {
          remember(Native_get(result_1, "error"));
          break;
        }
        default:
      }
    }
  };
  const readIfPresent = (name, apply) => {
    const path = join4(directory, name);
    if (Native_exists(path)) {
      apply(Native_read(path));
    }
  };
  const refresh = () => {
    if (!closed) {
      if (!controlFailed) {
        try {
          Native_require(Native_exists(directory), "Supervisor control directory is missing");
          if (Operators_IsNull(startResult)) {
            readIfPresent("started", (receipt) => {
              Native_fields(singleton("pid"), receipt);
              const pid = Native_value(receipt, "pid");
              Native_integer(2147483647, pid);
              Native_require(pid > 0, "Invalid target PID");
              targetPid = pid;
              settleStart(Native_objectOf([["kind", "Started"], ["pid", pid]]));
            });
            if (Operators_IsNull(startResult)) {
              readIfPresent("failed", (detail_1) => {
                remember(detail_1);
                settleStart(Native_objectOf([["kind", "Failed"], ["error", detail_1]]));
              });
            }
          }
          if (Operators_IsNull(targetExit)) {
            readIfPresent("exit", (receipt_1) => {
              Native_fields(ofArray(["code", "signal"]), receipt_1);
              const code = Native_value(receipt_1, "code");
              const signal = Native_value(receipt_1, "signal");
              if (!Operators_IsNull(code)) {
                Native_integer(2147483647, code);
              }
              if (!Operators_IsNull(signal)) {
                Native_text(false, signal);
              }
              Native_require(!(Operators_IsNull(code) && Operators_IsNull(signal)), "Target exit has no status");
              targetExit = receipt_1;
            });
          }
          if (!targetClosed) {
            readIfPresent("closed", (receipt_2) => {
              Native_fields(ofArray(["closed", "stdoutBytes", "stderrBytes"]), receipt_2);
              Native_require(equals(Native_value(receipt_2, "closed"), true), "Invalid closed witness");
              const stdout = Native_integer(9007199254740991, Native_value(receipt_2, "stdoutBytes"));
              const stderr = Native_integer(9007199254740991, Native_value(receipt_2, "stderrBytes"));
              targetOutput = [stdout, stderr];
              targetClosed = true;
            });
          }
          readIfPresent("fault", (detail_2) => {
            remember(detail_2);
            controlFailed = true;
          });
        } catch (error) {
          controlFailed = true;
          remember(Native_failure("control", error));
        }
      }
      const failedStart = !Operators_IsNull(startResult) && Native_get(startResult, "kind") === "Failed";
      const worker_1 = inner.inspect();
      const stdout_1 = Native_get(Native_get(worker_1, "stdout"), "observed");
      const stderr_1 = Native_get(Native_get(worker_1, "stderr"), "observed");
      let outputReceived;
      if (targetOutput == null) {
        outputReceived = false;
      } else {
        const expectedOut = targetOutput[0];
        const expectedErr = targetOutput[1];
        if (stdout_1 > expectedOut ? true : stderr_1 > expectedErr) {
          controlFailed = true;
          remember(Native_problem("output", "OUTPUT_COUNT_MISMATCH", "Received output exceeds the worker extent"));
        }
        outputReceived = stdout_1 === expectedOut && stderr_1 === expectedErr;
      }
      if ((targetClosed && (outputReceived ? true : capture === "Discarded") ? true : controlFailed) ? true : failedStart) {
        shutdown();
      }
      const workerPhase_1 = worker_1.phase;
      if (workerPhase_1 === "Draining" ? true : workerPhase_1 === "Closed") {
        if (Operators_IsNull(startResult)) {
          const detail_3 = Native_problem("supervision", "UNKNOWN_TARGET_START", "Supervisor ended without a target startup receipt");
          remember(detail_3);
          settleStart(Native_objectOf([["kind", "Failed"], ["error", detail_3]]));
        }
        if (Operators_IsNull(targetExit) && Native_get(startResult, "kind") !== "Failed") {
          remember(Native_problem("supervision", "UNKNOWN_TARGET_EXIT", "Supervisor ended without a target exit receipt"));
        } else if (!targetClosed && !shutdownRequested) {
          remember(Native_problem("supervision", "SUPERVISOR_LOST", "Supervisor ended before output closure was confirmed"));
        }
      }
      if (workerPhase_1 === "Closed" && capture !== "Open") {
        closed = true;
        clearTimeout(pollTimer);
        try {
          Native_remove(directory);
        } catch (error_1) {
          remember(Native_failure("cleanup", error_1));
        }
        const arr = toArray2(waits.values());
        for (let idx = 0; idx <= arr.length - 1; idx++) {
          item(idx, arr)();
        }
      }
    }
  };
  const poll = () => {
    refresh();
    if (!closed) {
      pollTimer = setTimeout(poll, 5);
    }
  };
  const waitResult = (kind_1) => Native_objectOf([["kind", kind_1], ["state", snapshot()]]);
  pollTimer = setTimeout(poll, 0);
  return {
    started() {
      return startup.then((_value) => JSON.parse(JSON.stringify(_value)));
    },
    inspect() {
      return guard(() => {
        refresh();
        return snapshot();
      });
    },
    read(channel, after) {
      return guard(() => inner.read(channel, after));
    },
    write(bytes) {
      return guard(() => inner.write(bytes));
    },
    endInput() {
      guard(() => {
        inner.endInput();
      });
    },
    signal(name_1) {
      return guard(() => {
        const result_3 = inner.signal(name_1);
        if (name_1 === "SIGKILL" && Native_get(result_3, "kind") === "Requested") {
          shutdownRequested = true;
          outputInterrupted = true;
        }
        return result_3;
      });
    },
    wait(milliseconds_1) {
      const milliseconds = milliseconds_1;
      return guard(() => {
        Native_integer(2147483647, milliseconds);
        Native_require(milliseconds > 0, "Wait duration must be positive");
        refresh();
        return closed ? Promise.resolve(waitResult("Closed")) : new Promise((resolve_1) => {
          const id = nextWait;
          nextWait = nextWait + 1;
          let finished = false;
          let timer = defaultOf();
          const finish_1 = (kind_2) => {
            if (!finished) {
              finished = true;
              waits.delete(id);
              clearTimeout(timer);
              resolve_1(waitResult(kind_2));
            }
          };
          addToDict(waits, id, () => {
            finish_1("Closed");
          });
          timer = setTimeout((() => {
            finish_1("TimedOut");
          }), ~~milliseconds);
        });
      });
    },
    takeOutput() {
      return guard(() => inner.takeOutput().then((result_2) => {
        const kind_3 = result_2.kind;
        switch (kind_3) {
          case "Closed": {
            refresh();
            if (targetOutput == null) {
            } else {
              const expectedOut_1 = targetOutput[0];
              const expectedErr_1 = targetOutput[1];
              const worker_2 = inner.inspect();
              const stdout_2 = Native_get(Native_get(worker_2, "stdout"), "observed");
              const stderr_2 = Native_get(Native_get(worker_2, "stderr"), "observed");
              if (stdout_2 !== expectedOut_1 ? true : stderr_2 !== expectedErr_1) {
                remember(Native_problem("output", outputInterrupted ? "OUTPUT_INTERRUPTED" : "OUTPUT_INCOMPLETE", "Capture ended before the complete worker extent was received"));
              }
            }
            capture = "Closed";
            refresh();
            return Native_objectOf([["kind", "Closed"], ["state", snapshot()]]);
          }
          case "Failed": {
            capture = "Failed";
            remember(Native_get(result_2, "error"));
            shutdown();
            refresh();
            return result_2;
          }
          case "Discarded": {
            capture = "Discarded";
            refresh();
            return result_2;
          }
          default:
            return result_2;
        }
      }));
    },
    discardOutput() {
      guard(() => {
        capture = "Discarded";
        inner.discardOutput();
        refresh();
      });
    }
  };
}
export {
  SupervisedProcess
};
