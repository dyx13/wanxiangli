import assert from 'node:assert/strict'
import { drainMicrotasks } from 'bun:jsc'
import { setTimeout as delay } from 'node:timers/promises'
import { ProcessSession } from 'wanxiangli/process'

const mode = process.argv[2]
assert.ok(['success', 'controlled-exit', 'real-exit-before-ack', 'controlled-write-error'].includes(mode))
const original = Bun.spawn
const notifications = []
let native
let sink
let resolveAck
let rejectAck
let injectExit
Bun.spawn = (command, options) => {
  const receiveExit = (child, code, signal, error) => {
    notifications.push({ source: 'runtime', code, signal: signal ?? null })
    options.onExit(child, code, signal, error)
  }
  native = original(command, { ...options, onExit: receiveExit })
  sink = native.stdin
  injectExit = () => {
    notifications.push({ source: 'controlled-notification', code: 23, physicalExitCodeAtInjection: native.exitCode })
    options.onExit(native, 23, null)
  }
  return {
    pid: native.pid,
    stdin: {
      write(bytes) {
        return Promise.resolve(sink.write(bytes)).then(() => sink.flush()).then(() => new Promise((resolve, reject) => {
          resolveAck = resolve
          rejectAck = reject
        }))
      },
      flush: () => sink.flush(),
      end: () => sink.end(),
    },
  }
}
let session
try {
  session = new ProcessSession({ executable: '/bin/cat', args: [], cwd: '/tmp', env: {}, tailBytes: 64, maxWriteBytes: 64 })
} finally { Bun.spawn = original }

try {
  assert.equal((await session.started()).kind, 'Started')
  const bytes = Buffer.from('one input')
  let callbackActive = false
  let settled = false
  let resumedInsideCheckpoint
  const pending = session.write(bytes).then(receipt => {
    settled = true
    resumedInsideCheckpoint = callbackActive
    return receipt
  })
  const deadline = performance.now() + 2000
  while (!resolveAck && performance.now() < deadline) await delay(1)
  assert.equal(typeof resolveAck, 'function')

  if (mode === 'real-exit-before-ack') {
    await sink.end()
    assert.equal(await native.exited, 0)
    assert.equal((await pending).kind, 'Unknown')
    resolveAck(bytes.length)
    drainMicrotasks()
  } else {
    callbackActive = true
    if (mode === 'controlled-write-error') rejectAck(Object.assign(new Error('Controlled native write rejection'), { code: 'CONTROLLED_WRITE_FAILURE' }))
    else resolveAck(bytes.length)
    drainMicrotasks()
    if (mode === 'controlled-write-error') assert.equal(settled, true, 'The error must not wait for a success immediate')
    else assert.equal(settled, false, 'Success must leave the current checkpoint')
    callbackActive = false
    if (mode === 'controlled-exit') injectExit()
  }

  const receipt = await pending
  assert.equal(receipt.kind, mode === 'success' ? 'Written' : 'Unknown')
  assert.equal(resumedInsideCheckpoint, mode === 'controlled-write-error')
  await new Promise(setImmediate)
  await new Promise(setImmediate)
  const afterLateSuccess = session.inspect()
  if (mode !== 'success') {
    assert.equal(afterLateSuccess.stdin, 'Failed')
    assert.throws(() => session.write(Buffer.from('not sent')), /not open/)
  }
  if (mode === 'controlled-write-error') assert.equal(receipt.error.code, 'CONTROLLED_WRITE_FAILURE')
  if (mode === 'success') session.endInput()
  else if (mode !== 'real-exit-before-ack') await sink.end()
  assert.equal(await native.exited, 0)
  assert.equal((await session.wait(2000)).kind, 'Closed')
  assert.equal(session.read('stdout', 0).text, bytes.toString())
  console.log(JSON.stringify({ mode, runtime: Bun.version, revision: Bun.revision, receipt, resumedInsideCheckpoint,
    afterLateSuccess, notifications, actualTargetExitCode: native.exitCode,
    scope: 'Small installed-package acknowledgement lifecycle only. controlled-exit deliberately injects a notification while the real cat is alive; the actual cat exits 0. real-exit-before-ack uses its real exit. No large-input or 17-byte-loss acceptance claim.' }, null, 2))
} finally {
  if (native.exitCode === null && native.signalCode === null) native.kill('SIGKILL')
  await native.exited
  await session.wait(2000)
}
