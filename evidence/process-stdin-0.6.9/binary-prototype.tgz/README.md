# D2 binary supervision prototype — exact wanxiangli 0.6.9

This is an independent, bounded physical feasibility probe. It is not the final D2 RawStore or production Hook acceptance.

## Fixed inputs

- Exact npm tarball: `wanxiangli-0.6.9.tgz`; SHA-256 `c0ed8fe889fe4e49cd19c7ae092c23892fdd9a73773c73ad40c8380ba409bd32`.
- Installed offline into a fresh private directory with `npm install --ignore-scripts --no-audit --no-fund --offline --cache ./npm-cache --prefix ./install ./wanxiangli-0.6.9.tgz`.
- Loaded the installed `dist/supervision/SupervisedProcess.js` bundle. SHA-256 `0bb25fc108f29e2321c72e4ce45b48fec9a6cccd18dff238f0f825be38bf16ca` matched `/Users/yuanxi/Workwork/wanxiangli/dist/supervision/SupervisedProcess.js` before and after both runs.
- Main package 652 SHA `003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887` is provenance for the old prototype only. This run does not consume that package or claim final main integration.
- Runtime: Node v26.6.0 and Bun 1.3.14 on macOS. Each runtime separately consumed the same installed tarball bytes.

## Runs and observations

`probe.mjs` is the exact probe used for both final logs, retaining the original full input size. Only the library path and provenance fields changed from the old prototype.

```
TMPDIR=/private/tmp/d2-supervised-binary-069.XGQaeh/node-tmp node /private/tmp/d2-supervised-binary-069.XGQaeh/probe.mjs > node.log 2>&1
TMPDIR=/private/tmp/d2-supervised-binary-069.XGQaeh/bun-tmp bun /private/tmp/d2-supervised-binary-069.XGQaeh/probe.mjs > bun.log 2>&1
```

The macOS supervision process-inspection call required authorized execution outside the filesystem sandbox. Both commands exited 0.

| Observation | Node | Bun |
|---|---:|---:|
| Binary input and exact readback | 33,554,449 bytes | 33,554,449 bytes |
| Write receipts | 16,777,216 / 16,777,216 / 17 bytes | 16,777,216 / 16,777,216 / 17 bytes |
| Native / supervised paired median | 10.62 / 51.84 ms | 11.44 / 57.03 ms |
| 500 ms hard deadline foreground return | 504.01 ms | 514.57 ms |
| Supervisor handles closed | 15/15 | 15/15 |

Both real Git write/read pairs produced blob OID `16c32402673aafa40f4aa4d3f16b75f4b713a75b`. The read occurs in a fresh supervised Git OS process; it does not share an object cache with the write. Twelve small native/supervised pairs compare actual code, stdout and stderr, including valid missing-ref exit 1. Median values are one local sample, not a product performance budget.

The deadline target ignores TERM and has its own finite safety exit. The runner requests group SIGKILL. Both final target exit receipts remain null with `UNKNOWN_TARGET_EXIT`, even though the supervisor is Closed and read-only PID observation confirms the owned target is absent after cleanup. This is the expected truthful Unknown result, not a fabricated SIGKILL target receipt. No command is resent after an Unknown write.

Both runtime-specific TMPDIRs were empty after completion. The owned Git repositories and the deadline fixture were removed by the probe.

## Historical counterexamples retained

The old 0.6.8 full-16MiB Bun run failed on the first write, and choosing 64KiB before a new run also failed later. The native Bun FileSink positive controls show that a small/zero immediate `.write()` count does not mean the remainder was discarded: `await flush()` plus `end()` delivers the full input. Those unchanged logs and the native control are included here. The previous-repair guard introduced in library commit `ca238c0` rejected that valid buffered state before flush; this is not an original split defect or a current D1 regression.

The first install attempt used npm's default cache, which was sandbox-inaccessible. `node-invalid-install-import.log` is the consequent import failure before the private-cache reinstall. It is a harness setup failure and is not counted as a product test or a binary regression.

## Evidence limits and reuse

This proves the bytes interface, chosen 16MiB chunking, ordinary Git cost sample and finite foreground deadline on the fixed library bundle. It does not prove final GitRawRunner output caps, parser validation, storage Result short-circuiting, public declaration compilation, actual Hook composition, or D2 old-path removal. Those remain the main work package's obligations.

The archive includes the exact tarball, exact probe and raw logs; it excludes the install directory and npm cache. To repeat elsewhere, install the included tarball in a fresh directory and update the single `library` constant in a copied probe to that installed bundle. Keep the archived probe unchanged and record the new input/source digest.
