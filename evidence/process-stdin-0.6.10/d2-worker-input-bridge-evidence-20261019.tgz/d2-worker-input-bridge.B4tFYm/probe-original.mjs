import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const product = '/private/tmp/d2-clean-install-659/node_modules/wanxiangshu'
const evidence = process.argv[2]
mkdirSync(evidence, { recursive: true })
const fixed = join(product, 'node_modules/wanxiangli/dist/process/ProcessSession.js')
const supervision = join(product, 'node_modules/wanxiangli/dist/supervision/SupervisedProcess.js')
const { ProcessSession } = await import(pathToFileURL(fixed))
const scratch = mkdtempSync('/private/tmp/d2-worker-input-run-')
const input = Uint8Array.from({ length: 2097169 }, (_, index) => index % 256)
input.set([239, 187, 191], 0)
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const describe = bytes => ({ bytes: bytes.length, sha256: sha(bytes) })
const before = { process: sha(readFileSync(fixed)), supervision: sha(readFileSync(supervision)) }
const results = []
const handles = []
try {
  writeFileSync(join(evidence, 'input.bin'), input)
  for (const mode of ['pipe', 'serial']) {
    const repo = join(scratch, mode)
    mkdirSync(repo)
    const witness = join(repo, 'tee-target.bin')
    const trace = join(repo, 'bridge-trace.json')
    const session = new ProcessSession({ executable: '/opt/homebrew/bin/bun', args: ['/private/tmp/d2-worker-input-bridge.B4tFYm/bridge.mjs', mode, repo, witness, trace], cwd: repo, env: { PATH: process.env.PATH }, tailBytes: 0, maxWriteBytes: 16777216 }, 'Capture')
    handles.push(session)
    const channels = { stdout: [], stderr: [] }
    const capture = (async () => { while (true) { const output = await session.takeOutput(); if (output.kind !== 'Chunk') return output; channels[output.channel].push(Buffer.from(output.bytes)) } })()
    const started = await session.started()
    assert.equal(started.kind, 'Started')
    const write = await session.write(input)
    session.endInput()
    const terminal = await capture
    const closed = await session.wait(1000)
    const stdout = Buffer.concat(channels.stdout)
    const stderr = Buffer.concat(channels.stderr)
    const actual = readFileSync(witness)
    const bridgeTrace = JSON.parse(readFileSync(trace, 'utf8'))
    writeFileSync(join(evidence, `${mode}.stdout.bin`), stdout)
    writeFileSync(join(evidence, `${mode}.stderr.bin`), stderr)
    writeFileSync(join(evidence, `${mode}.target.bin`), actual)
    writeFileSync(join(evidence, `${mode}.trace.json`), JSON.stringify(bridgeTrace, null, 2) + '\n')
    const result = { mode, outerHost: process.execPath, started, write, terminal, closed, expected: describe(input), target: describe(actual), stdout: describe(stdout), stderr: describe(stderr), targetEqual: actual.equals(Buffer.from(input)), stdoutEqual: stdout.equals(Buffer.from(input)), bridgeTrace }
    results.push(result)
    console.log(JSON.stringify(result))
  }
  assert.deepEqual({ process: sha(readFileSync(fixed)), supervision: sha(readFileSync(supervision)) }, before)
  writeFileSync(join(evidence, 'summary.json'), JSON.stringify({ fixedProduct: product, fixedSources: before, outerHost: process.execPath, results, scope: 'Minimal private Worker input bridge using the exact fixed bundled BunProcess.spawn/output functions, exposed only by adding two export names to a private byte-copy. Actual fixed ProcessSession supplies input/captures output. Target tee file is independent native evidence. Shared package files are unchanged. Instance _write/_final wrappers only record callback facts and delegate unchanged.' }, null, 2) + '\n')
} finally {
  for (const session of handles) { session.signal('SIGKILL'); session.discardOutput(); await session.wait(5000) }
  rmSync(scratch, { recursive: true, force: true })
  console.log(JSON.stringify({ cleanup: true, scratchRemoved: !existsSync(scratch), fixedPackageUnchanged: true }))
}
