import assert from 'node:assert/strict'
import fs from 'node:fs'
import { setTimeout as delay } from 'node:timers/promises'
import { SupervisedProcess } from './wanxiangli/dist/supervision/SupervisedProcess.js'

const [mode, directory] = process.argv.slice(2)
const bytes = Buffer.from([0, 255, 13, 10, 250, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11])
fs.mkdirSync(directory, { recursive: true })
const record = { host: process.versions.bun ? `Bun ${process.versions.bun}` : `Node ${process.version}`, mode, controlledSourceEvent: mode !== 'gate', realNativeStdinAndTarget: true }
const run = new SupervisedProcess({ executable: '/opt/homebrew/bin/node', args: ['/private/tmp/d2-0612-checkpoints/target.mjs'], cwd: directory, env: { D2_PATH: directory, D2_MODE: mode }, tailBytes: 0, maxWriteBytes: 65536 })
const stdout = [], stderr = []
const capture = (async () => {
  for (;;) {
    const result = await run.takeOutput()
    if (result.kind !== 'Chunk') return result
    const destination = result.channel === 'stdout' ? stdout : stderr
    destination.push(Buffer.from(result.bytes))
  }
})()
const until = async (read, message) => {
  const deadline = performance.now() + 8000
  while (performance.now() < deadline) {
    const result = read()
    if (result) return result
    await delay(5)
  }
  throw new Error(message)
}
const checkpoint = () => JSON.parse(fs.readFileSync(`${directory}/checkpoint.json`, 'utf8'))
try {
  record.start = await run.started()
  assert.equal(record.start.kind, 'Started')
  record.supervisor = run.inspect().supervisor.pid
  await until(() => fs.existsSync(`${directory}/target-ready`), 'real target did not become ready')
  record.write = await run.write(bytes)
  assert.ok(record.write.kind === 'Written' || record.write.kind === 'Unknown')
  run.endInput()
  if (mode === 'gate') {
    record.held = await until(() => {
      const value = checkpoint()
      return value.sourceEnd && value.physicalCallbacks === 1 ? value : null
    }, 'real source end and physical write callback were not both observed')
    assert.equal(record.held.pending, 1)
    assert.equal(record.held.callbacksReleased, 0)
    assert.equal(record.held.endCalls, 0)
    assert.equal(fs.existsSync(`${directory}/target-eof`), false)
    fs.writeFileSync(`${directory}/release`, 'release the actual target write callback')
  }
  record.terminal = await capture
  record.closed = await run.wait(5000)
  assert.equal(record.closed.kind, 'Closed')
  record.checkpoint = checkpoint()
  assert.equal(record.checkpoint.maxReadDepth, 1)
  assert.equal(record.checkpoint.endWhilePending, 0)
  if (mode === 'read-error') {
    assert.equal(record.checkpoint.injected, true)
    assert.equal(record.checkpoint.injectedBytes, bytes.length)
    assert.equal(record.checkpoint.writeCalls, 0)
    assert.equal(record.checkpoint.endCalls, 0)
    assert.equal(record.closed.state.failure.operation, 'stdin')
    assert.equal(record.closed.state.failure.code, 'D2_CONTROLLED_SOURCE_ERROR')
  } else {
    assert.equal(record.closed.state.failure, null)
    assert.deepEqual(record.closed.state.exit, { code: 23, signal: null })
    assert.equal(record.checkpoint.writeCalls, 1)
    assert.equal(record.checkpoint.maxPending, 1)
    assert.equal(record.checkpoint.endCalls, 1)
    assert.deepEqual(fs.readFileSync(`${directory}/target-input.bin`), bytes)
    assert.deepEqual(Buffer.concat(stdout), Buffer.from([0, 255, 13, 10]))
    assert.deepEqual(Buffer.concat(stderr), Buffer.from([255, 0, 10]))
  }
  record.accepted = true
} catch (error) {
  record.error = { message: error.message, stack: error.stack }
  process.exitCode = 1
} finally {
  run.signal('SIGKILL')
  run.discardOutput()
  record.cleanup = await run.wait(5000)
  fs.writeFileSync(`${directory}/stdout.bin`, Buffer.concat(stdout))
  fs.writeFileSync(`${directory}/stderr.bin`, Buffer.concat(stderr))
  fs.writeFileSync(`${directory}/record.json`, JSON.stringify(record, null, 2))
  console.log(JSON.stringify(record))
}
