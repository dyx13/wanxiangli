import { readSync, writeFileSync } from 'node:fs'

const directory = process.env.D2_PATH
process.stdout.write(Buffer.from([0, 255, 13, 10]))
process.stderr.write(Buffer.from([255, 0, 10]))
writeFileSync(`${directory}/target-ready`, String(process.pid))
const chunks = []
for (;;) {
  const bytes = Buffer.alloc(65536)
  const count = readSync(0, bytes, 0, bytes.length, null)
  if (count === 0) break
  chunks.push(bytes.subarray(0, count))
}
writeFileSync(`${directory}/target-input.bin`, Buffer.concat(chunks))
writeFileSync(`${directory}/target-eof`, String(process.pid))
process.exitCode = 23
