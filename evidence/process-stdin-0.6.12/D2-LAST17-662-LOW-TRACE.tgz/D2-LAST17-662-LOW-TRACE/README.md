# D2 candidate 662: low-volume observation reproduces missing tail

This is a preregistered single observational run, not passing acceptance. Bun 1.3.14 on macOS arm64. The included candidate package SHA256 is `163083cec3e51cf788747c965bda63e20840d159c17a19bbabb869d769d96795`, with wanxiangli 0.6.11. This candidate still fails the complete-input obligation.

The original 19 test bodies and assertions were retained. A private whole-package copy changed only the two generated files listed in `experiment/preregister.json`. Their exact diffs and before/after files are included. In memory, native writes record bytes, immediate native write result, flush result, callback status and end result. The worker iterator records source total bytes/chunks, successfully acknowledged target bytes and EOF. There is no observation I/O inside write, flush, callbacks, source iteration or EOF. Each native child appends one JSON snapshot only after actual close and the original close event emission. This still perturbs timing and earlier test lifecycle; it is evidence about this run, not a general guarantee.

The one full Bun sequence returned 18 pass / 1 fail. The 33554449-byte write returned the exact 33554432-byte prefix OID. The two larger controls passed. `run.log` preserves the original assertion and native comparison.

For the failed write, parent process 74085 wrote to worker 74161 using three native writes [16777216, 16777216, 17]. The final write reported count 17, flush 17, callback success; end returned 0. Worker 74161's source iterator produced only 33554432 bytes, acknowledged that many target bytes, and reached EOF with no recorded error. Target Git 74163 received 33554432 bytes through the second native writer and exited 0. `closed.ndjson` is raw; `large-handoff-summary.json` joins the parent and child rows by actual PID.

This isolates the missing bytes to before the worker iterator's yielded-byte boundary in this run. It excludes the second native stdin hop as the location of these particular missing bytes. It does not uniquely distinguish first-hop physical delivery from a Bun iterator buffering/EOF defect. The experiment started before a request to inspect source readableLength/readableEnded/destroyed/closed; these fields are absent and the experiment was not rerun to add them. No precise lower-layer cause is asserted.

The actual failed repository `repositories/wxs-binary-git-IvBlsr` is included. Native Node read the object through native Git with stdout sent directly to a file descriptor. Its actual bytes are exactly the first 33554432 bytes of the expected 33554449 bytes: all preceding bytes match, 17 trailing bytes are absent. The expected input was regenerated from the unchanged deterministic test rule `index % 251`, not claimed to be an original Buffer dump. Native Node crypto and native Git with a file descriptor agree on the expected full OID.

The fixture deliberately retains central repositories instead of deleting them. As in the preceding Bun test run, its auxiliary process-exit repository JSON handler did not run; `retained-repo-inventory.json` is the subsequent native inventory of 11 repositories created since preregistration. Only the failed repository is copied here; originals remain on the test machine. Cleanup records cover observed PIDs only.

To independently reread the physical failed object after extraction, run from this directory:

```sh
node probes/d2-cold-object-compare.mjs repositories/wxs-binary-git-IvBlsr 284160124c6f2e4694b0fee82bfb1fe73746b962 experiment/input-33554449.bin /private/tmp/d2-662-archived-actual.bin /private/tmp/d2-662-archived-cold.json
shasum -a 256 -c MANIFEST.sha256
```

Original fixture absolute imports are preserved as provenance and need their original private installation. The native cold-reader above is portable with Node and `/usr/bin/git`. No production source or installed fixed package was changed. The older 661 high-volume trace pass remains separate and is not substituted for this red. R12-U1 remains deferred.
