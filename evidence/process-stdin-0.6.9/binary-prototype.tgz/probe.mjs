import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFile, spawnSync } from 'node:child_process'
import { existsSync, mkdtempSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const library = '/private/tmp/d2-supervised-binary-069.XGQaeh/install/node_modules/wanxiangli/dist/supervision/SupervisedProcess.js'
const { SupervisedProcess } = await import(pathToFileURL(library).href)
const root = mkdtempSync(join(tmpdir(), 'd2-binary-prototype-'))
const executable = '/usr/bin/git'
const environment = Object.fromEntries(Object.entries(process.env).filter(([, value]) => typeof value === 'string'))
const maxWriteBytes = 16 * 1024 * 1024
const inputChunkBytes = Number(process.env.D2_INPUT_CHUNK_BYTES ?? maxWriteBytes)
assert.ok(Number.isInteger(inputChunkBytes) && inputChunkBytes > 0 && inputChunkBytes <= maxWriteBytes)
const sessions = []

const native = (args, input) => new Promise((resolve, reject) => {
  const start = performance.now()
  const child = execFile(executable, args, { cwd: root, encoding: 'buffer', timeout: 10000, maxBuffer: 64 * 1024 * 1024 }, (error, stdout, stderr) => {
    if (error && typeof error.code !== 'number') return reject(error)
    resolve({ elapsedMs: performance.now() - start, code: error?.code ?? 0, stdout: Buffer.from(stdout), stderr: Buffer.from(stderr) })
  })
  child.stdin.on('error', reject)
  child.stdin.end(input)
})

async function supervised(executable, args, input, deadlineMs = 10000, graceMs = 1000) {
  const begin = performance.now()
  const process = new SupervisedProcess({ executable, args, cwd: root, env: environment, tailBytes: 0, maxWriteBytes })
  const record = { executable, args, started: null, writeReceipts: [], chunks: { stdout: 0, stderr: 0 }, stopRequested: false, state: null, elapsedMs: null }
  sessions.push({ process, record })
  const bytes = { stdout: [], stderr: [] }
  const cursors = { stdout: 0, stderr: 0 }
  let captureComplete = false
  let fault = null
  let timer
  let foregroundExpired
  const expired = new Promise(resolve => { foregroundExpired = resolve })
  timer = setTimeout(() => {
    record.stopRequested = true
    record.signalReceipt = process.signal('SIGKILL')
    record.grace = setTimeout(() => foregroundExpired('deadline-grace'), graceMs)
  }, deadlineMs)
  const consume = async () => {
    while (true) {
      const output = await process.takeOutput()
      if (output.kind === 'Chunk') {
        assert.equal(output.from, cursors[output.channel])
        assert.equal(output.to - output.from, output.bytes.length)
        cursors[output.channel] = output.to
        bytes[output.channel].push(Buffer.from(output.bytes))
        record.chunks[output.channel] += 1
      } else if (output.kind === 'Closed') {
        record.state = output.state
        captureComplete = output.state.failure === null && output.state.capture === 'Closed'
        return 'closed'
      } else {
        fault = output
        process.signal('SIGKILL')
        process.discardOutput()
        record.state = (await process.wait(1000)).state
        return output.kind
      }
    }
  }
  try {
    record.started = await process.started()
    assert.equal(record.started.kind, 'Started', JSON.stringify(record.started))
    const consumer = consume()
    const feed = (async () => {
      if (input) {
        for (let offset = 0; offset < input.length; offset += inputChunkBytes) {
          const chunk = input.subarray(offset, Math.min(offset + inputChunkBytes, input.length))
          const receipt = await process.write(chunk)
          record.writeReceipts.push(receipt)
          assert.equal(receipt.kind, 'Written', JSON.stringify(receipt))
          assert.equal(receipt.bytes, chunk.length)
        }
      }
      process.endInput()
    })()
    const foreground = await Promise.race([Promise.all([consumer, feed]).then(() => 'settled'), expired])
    record.elapsedMs = performance.now() - begin
    record.foreground = foreground
    record.state ??= process.inspect()
    if (foreground !== 'settled') {
      process.signal('SIGKILL')
      process.discardOutput()
      const cleanup = await process.wait(5000)
      record.cleanup = cleanup
      assert.equal(cleanup.kind, 'Closed')
      await consumer
      await feed
    }
    const closed = await process.wait(1000)
    assert.equal(closed.kind, 'Closed', JSON.stringify(closed.state))
    record.finalState = closed.state
    record.captureComplete = captureComplete
    record.fault = fault
    return { record, stdout: Buffer.concat(bytes.stdout), stderr: Buffer.concat(bytes.stderr) }
  } finally {
    clearTimeout(timer)
    clearTimeout(record.grace)
    delete record.grace
  }
}

try {
  assert.equal(spawnSync(executable, ['init', '--quiet', root]).status, 0)
  const input = Buffer.alloc(2 * maxWriteBytes + 17)
  for (let index = 0; index < input.length; index++) input[index] = index & 0xff
  const expected = await native(['hash-object', '--stdin'], input)
  const binary = await supervised(executable, ['hash-object', '-w', '--stdin'], input)
  assert.deepEqual(binary.stdout, expected.stdout)
  const expectedWriteSizes = []
  for (let offset = 0; offset < input.length; offset += inputChunkBytes) expectedWriteSizes.push(Math.min(inputChunkBytes, input.length - offset))
  assert.deepEqual(binary.record.writeReceipts.map(receipt => receipt.bytes), expectedWriteSizes)
  assert.equal(binary.record.captureComplete, true)
  assert.equal(binary.record.state.exit.code, 0)
  const writtenOid = binary.stdout.toString().trim()
  const readback = await supervised(executable, ['cat-file', 'blob', writtenOid])
  assert.deepEqual(readback.stdout, input)
  assert.equal(readback.record.captureComplete, true)

  const paired = []
  const commands = [
    { args: ['rev-parse', '--is-inside-work-tree'], input: undefined },
    { args: ['hash-object', '--stdin'], input: Buffer.from('owned binary timing\n') },
    { args: ['mktree', '-z'], input: Buffer.alloc(0) },
    { args: ['rev-parse', '--verify', '--quiet', 'refs/wanxiang/missing'], input: undefined },
  ]
  for (let round = 0; round < 3; round++) {
    for (const command of commands) {
      let direct
      let guarded
      if (round % 2 === 0) {
        direct = await native(command.args, command.input)
        guarded = await supervised(executable, command.args, command.input)
      } else {
        guarded = await supervised(executable, command.args, command.input)
        direct = await native(command.args, command.input)
      }
      assert.equal(guarded.record.state.exit.code, direct.code)
      assert.deepEqual(guarded.stdout, direct.stdout)
      assert.deepEqual(guarded.stderr, direct.stderr)
      assert.equal(guarded.record.captureComplete, true)
      paired.push({ round, args: command.args, nativeMs: direct.elapsedMs, supervisedMs: guarded.record.elapsedMs })
    }
  }

  const ignore = join(root, 'ignore-term.mjs')
  writeFileSync(ignore, "import { writeFileSync } from 'node:fs'; process.on('SIGTERM', () => {}); writeFileSync(1, 'ready\\n'); setTimeout(() => process.exit(0), 4000);\n")
  const deadline = await supervised(process.execPath, [ignore], undefined, 500, 250)
  assert.equal(deadline.record.stopRequested, true)
  assert.ok(deadline.record.elapsedMs < 2000)
  if (deadline.record.finalState.exit === null) {
    assert.notEqual(deadline.record.finalState.failure, null)
  } else {
    assert.equal(deadline.record.finalState.exit.signal, 'SIGKILL')
  }
  assert.equal(deadline.record.finalState.supervisor.phase, 'Closed')
  const present = pid => {
    try { process.kill(pid, 0); return true }
    catch (error) { if (error.code === 'ESRCH') return false; throw error }
  }
  for (let attempt = 0; attempt < 50 && present(deadline.record.started.pid); attempt++) await new Promise(resolve => setTimeout(resolve, 10))
  deadline.record.targetAbsentAfterCleanup = !present(deadline.record.started.pid)
  assert.equal(deadline.record.targetAbsentAfterCleanup, true)

  const median = values => [...values].sort((a, b) => a - b)[Math.floor(values.length / 2)]
  const summary = {
    runtime: process.versions.bun ? `Bun ${process.versions.bun}` : `Node ${process.version}`,
    library,
    libraryVersion: '0.6.9',
    maxWriteBytes,
    inputChunkBytes,
    exactLibraryPackage: 'c0ed8fe889fe4e49cd19c7ae092c23892fdd9a73773c73ad40c8380ba409bd32',
    baselineMainPackage: '003bc8818969597f9afd6a1c0767c7aae271dd53e5f0392b146367d156ec3887',
    binary: { inputBytes: input.length, inputSha256: createHash('sha256').update(input).digest('hex'), oid: writtenOid, write: binary.record, read: readback.record },
    paired,
    pairedMedianMs: { native: median(paired.map(pair => pair.nativeMs)), supervised: median(paired.map(pair => pair.supervisedMs)) },
    deadline: deadline.record,
    ownedSessions: sessions.length,
    allSupervisorHandlesClosed: sessions.every(({ record }) => record.finalState?.supervisor.phase === 'Closed'),
  }
  assert.equal(summary.allSupervisorHandlesClosed, true)
  console.log(JSON.stringify(summary, null, 2))
} catch (error) {
  console.error(JSON.stringify({ failed: error.message, inputChunkBytes, sessions: sessions.map(({ process, record }) => ({ ...record, latest: process.inspect() })) }, null, 2))
  throw error
} finally {
  for (const { process, record } of sessions) {
    if (record.finalState?.supervisor.phase !== 'Closed') {
      process.signal('SIGKILL')
      process.discardOutput()
      await process.wait(5000)
    }
  }
  rmSync(root, { recursive: true, force: true })
}
