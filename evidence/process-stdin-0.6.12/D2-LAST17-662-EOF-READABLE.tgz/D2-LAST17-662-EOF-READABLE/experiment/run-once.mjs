import { spawn, spawnSync } from 'node:child_process'
import { closeSync, openSync, writeFileSync } from 'node:fs'

const directory = '/private/tmp/d2-662-eof-probe'
const log = openSync(`${directory}/run.log`, 'wx')
const child = spawn('/opt/homebrew/bin/bun', ['test', `${directory}/017-probe.test.mjs`], {
  cwd: '/Users/yuanxi/Workwork/vibe-fs',
  env: { ...process.env, WXS_TIER_INTEGRATION: '1' },
  stdio: ['ignore', log, log],
})
const startedAt = new Date().toISOString()
const status = { startedAt, pid: child.pid, deadlineMs: 120000, timedOut: false, cleanup: [] }
const ownedProcesses = () => {
  const result = spawnSync('/bin/ps', ['-axo', 'pid=,ppid=,command='], { encoding: 'utf8' })
  if (result.status !== 0) return { error: result.stderr, rows: [] }
  const rows = result.stdout.split('\n').flatMap(line => {
    const match = line.match(/^\s*(\d+)\s+(\d+)\s+(.*)$/)
    return match ? [{ pid: Number(match[1]), ppid: Number(match[2]), command: match[3] }] : []
  })
  const owned = new Set([child.pid, ...rows.filter(row => row.pid !== process.pid && row.command.includes(`${directory}/wanxiangshu/`) && row.command.includes('--wanxiangli-supervisor')).map(row => row.pid)])
  let changed = true
  while (changed) {
    changed = false
    for (const row of rows) {
      if (owned.has(row.ppid) && !owned.has(row.pid)) {
        owned.add(row.pid)
        changed = true
      }
    }
  }
  return { rows: rows.filter(row => owned.has(row.pid) && row.pid !== process.pid) }
}
const deadline = setTimeout(() => {
  status.timedOut = true
  status.beforeKill = ownedProcesses()
  for (const row of status.beforeKill.rows.reverse()) {
    for (const target of [-row.pid, row.pid]) {
      try {
        process.kill(target, 'SIGKILL')
        status.cleanup.push({ target, sent: true })
      } catch (error) {
        status.cleanup.push({ target, error: error.code })
      }
    }
  }
  writeFileSync(`${directory}/status.json`, JSON.stringify(status, null, 2))
}, 120000)
child.on('error', error => { status.error = error.message })
child.on('close', (code, signal) => {
  clearTimeout(deadline)
  closeSync(log)
  Object.assign(status, { closedAt: new Date().toISOString(), code, signal, afterClose: ownedProcesses() })
  writeFileSync(`${directory}/status.json`, JSON.stringify(status, null, 2))
  console.log(JSON.stringify(status))
  process.exitCode = status.timedOut ? 124 : code ?? 1
})
