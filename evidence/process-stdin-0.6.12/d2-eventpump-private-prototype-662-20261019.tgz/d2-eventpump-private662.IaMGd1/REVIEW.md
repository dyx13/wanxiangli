# Private event/readable input pump prototype

This is a private prototype, not a published package or a shared source change.
The fixed input is generation 662, package SHA256
`163083cec3e51cf788747c965bda63e20840d159c17a19bbabb869d769d96795`.
The original 11,041 dependency/product files were compared. Only the copied
wanxiangli supervision bundle changes: an import of `pump.mjs` and replacement
of the Worker input iterator call. The Host, raw Git store and actual consumer
implementation remain unchanged. Original and private supervision bundles plus
their exact hash difference are retained.

The pump listens to readable/end/close, drains actual `source.read()` bytes and
keeps only one target write callback pending. It forwards end only after a real
end event or `readableEnded`. It treats close without end as an input fault.
Target refusal detaches only its own listeners; it does not destroy or close
the borrowed source/fd0 and does not retry input. The once-per-terminal trace is
an observation fixture; no per-chunk trace I/O runs.

## Predeclared runs and results

The full original 017 body ran once under Bun test with the integration tier
enabled: 19 pass, 0 fail. This includes its three large Git writes, the 2 MiB
duplex tee, true cold child readers, permission failures, signal/deadline and
binary protocol controls. The private fixture only changes product URLs,
retains repositories and records their inventory. The three large actual Git
objects were then extracted with independent native Git without running any
product input again. Their full bytes equal the expected 32 MiB + 17,
64 MiB and 64 MiB + 17 pattern and their independent native OIDs match.

Two additional real rejection cases ran once each. The immediate-close target
publishes readiness only after closing fd0. The partial target accumulates
exactly 64 KiB, closes fd0, then publishes readiness. Each waits behind a file
gate. The parent observes the actual pump EPIPE/target-rejected result before
releasing that gate; only then may the target emit over 2 MiB on each channel
and exit 23. Both cases passed with complete channels and correct target bytes.
The source was still open and undestroyed at rejection. In the partial case it
retained 1,310,737 bytes for its owner, demonstrating the pump did not destroy
the borrowed source to stop forwarding.

A third physical boundary case inherited an actual directory as Worker fd0.
Bun rejected construction of process.stdin with EISDIR from fstat. The Worker
published operation `worker`, with no target exit or scope-closed receipt.
The fixture mistakenly expected operation `stdin`, so the combined boundary
command exits 1. Its complete original log, fault and control files remain.
This is a fixture classification error, not evidence that the pump's read-error
callback was exercised. It proves only the upstream Worker error remained
explicit and did not become successful EOF. The owned process group was killed
and awaited in finally. No fake source error was emitted.

## Remaining design gap

Root review found that this prototype sets `pending` after `source.read()`.
Because read may synchronously emit readable/end/close/error, the source-read
operation itself must also be covered by the same pending flag. After read,
the code must check whether a synchronous source error already stopped the
pump before sending returned bytes. This exact private candidate does not have
that guard, and the successful physical cases do not prove synchronous read
reentrancy safe. Do not copy it unchanged into production or claim completion.

The known 661/662 original iterator failures remain preserved separately.
The EOF diagnostic showed 17 bytes still in the Node-compatible Readable after
the iterator returned; source.read retrieved them and direct fd0 then returned
zero. This supports replacing the iterator before adding another physical
backend, but this prototype's green runs are not a guarantee against all cases.
No raw-fd reader, Web reader or FIFO replacement was implemented in this step.

## Replay

The private clone remains at this exact path. Run each command at most once for
the same finite matrix and retain any changed outcome:

```sh
WXS_TIER_INTEGRATION=1 bun test ./017-eventpump.test.mjs
bun ./physical-boundaries.mjs
```

The second command intentionally retains the original mistaken `stdin`
assertion and therefore exits 1 on the recorded Worker-level EISDIR. No rerun
was used to turn it green. The native extraction code is a read-only operation
over retained objects, not another write/consumer execution.
