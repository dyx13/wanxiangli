# 0.6.11 stdin 回执边界：非作者限定复审

本次没有修改共享源码，没有重复大输入测试。结论只覆盖回执与生命周期边界：未发现此窄改动的新回退；实际物理末尾 17 字节问题仍未解决。主代理已报告 662 的真实 Bun 大输入反例仍红，整体 D2 不闭合。

## 固定输入与实际消费

库包：`wanxiangli-0.6.11.tgz`，SHA-256 `aa112c11957468cbcfc0cb8e4a340326572484cca2b7803cfdffa2d0b75614a4`。使用离线 npm 干净安装，安装日志为 `install.log`；消费者只导入该安装包的 `wanxiangli/process`，不读取库源码替代产物。运行时为实际 Bun 1.3.14、revision `d1632b2918dfa83f43686946325bcc9cceab6594`。

`reviewed-BunProcess.fs` 和 `reviewed-002.test.mjs` 是此次只读审查时的源码快照；`author-fixture.mjs` 是复制的作者子进程夹具。包 SHA 与源码快照分别固定，源码快照自身不冒充编译输入闭包证明。

## 生产 guard 与 lifecycle

成功分支等待 write、flush 后，只安排 `setImmediate(() => complete())`。原 complete 才检查并设置 completed、清 pendingWrite、交付 callback。因而成功尚未交付时，exit 或失败仍可即时结算；排队成功后来经过同一 guard，不能覆盖它。没有提前清 pending，没有新增重试、改块、毫秒延迟或公共配置。

ProcessSession 在错误时把 stdin 置 Failed，close 不覆盖 Failed；之后拒绝再次写入。此次改变不把 Written 解释为目标消费或处理完成，也不使输入结束代替输出收齐/进程结束。Node 路径没有随此窄改动改变。

## 作者测试的事实边界

干净安装包复跑 success/exit 两个小例均通过。它们确实经过实际 cat 和实际字节输入，但 exit 模式调用的是受控 `options.onExit(...,23)`，当时真实 cat 仍在运行。之后夹具关闭真实 stdin，实际 cat 退出 0。它证明“收到退出通知与排队成功竞争时 Unknown 优先”，不能证明真实物理退出码 23，也不能证明原大输入失败同因。

主代理已把父测试标题明确改成 controlled notification，并在记录中说明实际 cat 退出 0。这个措辞修正是测试证据分类，不能列为生产生命周期错误的修复。

## 四个独立小例

`independent.mjs` 同样只消费干净固定包，并增加运行时通知来源、真实退出码、两轮 immediate 后的 stdin 状态和字节结果检查：

| 小例 | 实际观察 |
|---|---|
| success | Written 9 字节，调用方不在原 checkpoint 恢复，真实 cat 回显相等并退出 0 |
| controlled-exit | 注入通知 23 时 physicalExitCode=null；Unknown，排队成功后 stdin 仍 Failed；实际运行时通知与真实退出均为 0 |
| real-exit-before-ack | 先关闭真实 sink 让 cat 实际退出 0，再释放 held ack；Unknown，late success 不改变 Failed，没有伪造退出通知 |
| controlled-write-error | 注入 `CONTROLLED_WRITE_FAILURE`，本 checkpoint 内即时 Unknown；错误码保留，后来无成功覆盖；真实 cat 回显相等并退出 0 |

所有错误分支随后都拒绝再次 write。日志保留实际 phase；比如受控退出通知后可能处于 Draining，而实际退出先到的分支已 Closed，不把这两种状态混写。夹具 finally 等待实际 native.exited 并等待会话收尾。

这些小例增加了非作者实际包证据，但没有执行原生 FileSink.onWrite 的栈内探针，也没有复现或消除原大输入丢尾。因此不能以“两红转两绿”或这四项通过关闭物理问题。Promise 只结算一次本身也不被冒充为每个原生 callback 都只被调用一次的全部证明；静态 guard、晚到行为及可见状态分别提供限定证据。

## 主仓 661 与下一包的比较准备

`main-661-baseline.json` 记录九个模块的 `.fs`、`.fsi` 与 661 实际安装产物 `.js` SHA-256 映射：GitTypes、ProcessGitRawStore、GitRawSurface、WriterStreamSync、RetentionSurface、Gateway、Hook Sync、ProcessRunner、NodeProcessHost。

源码/FSI 是本次审查时的独立快照，661 JS 来自其实际固定安装包。此映射自身不能倒推 661 当时全部编译输入；未来比较时可准确发现所列源码/FSI/JS 是否变化。`main-661-self-check.log` 只是比较工具对自身基线的检查，不是新包验收，更不覆盖 nested wanxiangli 改动或整体产品正确性。

待有明确下一包固定路径后运行：

```sh
node main-map.mjs compare main-661-baseline.json <main-source-root> <next-installed-main-root>
```

然后按主代理要求重跑 Raw、树协议、消费者的限定验收。整体大输入红、原始失败与重放绿继续分别保留；R12-U1 仍暂缓。

## 复现

```sh
npm install --offline --ignore-scripts --no-audit --no-fund --package-lock=false ./wanxiangli-0.6.11.tgz
bun author-fixture.mjs success
bun author-fixture.mjs exit
bun independent.mjs success
bun independent.mjs controlled-exit
bun independent.mjs real-exit-before-ack
bun independent.mjs controlled-write-error
```

原日志保持不变。SHA256SUMS 固定说明、原型、各日志、源码审查快照、映射与实际库包；node_modules/npm 缓存不进入归档。
