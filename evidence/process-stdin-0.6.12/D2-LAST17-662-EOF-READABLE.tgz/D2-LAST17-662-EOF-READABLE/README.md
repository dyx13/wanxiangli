# D2 candidate 662: iterator stops with the exact tail in Readable

This is one preregistered diagnostic experiment on a private fixed-662 copy, not a production acceptance run. The candidate archive is included, SHA256 `163083cec3e51cf788747c965bda63e20840d159c17a19bbabb869d769d96795`, library 0.6.11. Bun 1.3.14, macOS arm64, Node 26.6.0, native Git 2.50.1 (Apple Git-155).

The preceding low-volume counter experiment had localized the missing 17 bytes to before the worker iterator's yielded-byte boundary. This follow-up was authorized to distinguish first-hop delivery from iterator buffering. It retained the original 19 test bodies and assertions, with absolute private-product imports and central repository retention. Only the two generated files listed in `experiment/preregister.json` changed; exact before/after files and diffs are included. Native writes and source iteration only update memory counters. Each actual native child close writes one snapshot after the original close emission.

At the worker iterator's natural completion, before target.end, this probe records source readableLength/readableEnded/destroyed/closed, calls source.read() once, then calls native fs.readSync(0) once with a buffer of at most 65536 bytes. The native read can block. An independent Node runner enforces an external 120-second deadline and owns cleanup of this test's child/supervisors/descendants. No timeout or forced cleanup occurred in the actual run. Diagnostic bytes are intentionally not forwarded to the target; this is a destructive observation of EOF behavior, not a proposed production repair.

The single full Bun sequence returned 18 pass / 1 fail. For the failed 33554449-byte write:

- Parent 75045 supplied worker 75114 with [16777216, 16777216, 17]. The last write reported 17, flush reported 17, callback succeeded. Parent end completed at 2026-10-18T17:22:33.350Z.
- Worker source iterator produced and acknowledged 33554432 bytes, then naturally completed at 2026-10-18T17:22:33.353Z.
- Before the diagnostic read, source states were readableLength=17, readableEnded=false, destroyed=true, closed=true.
- source.read() returned exactly 17 bytes: hex `fa000102030405060708090a0b0c0d0e0f`, base64 `+gABAgMEBQYHCAkKCwwNDg8=`. These bytes exactly equal the expected input tail at offset 33554432. Both the actual read and expected tail are retained as binary files and compared in `tail-verification.json`.
- The following native fd0 read returned 0. Target Git 75116 received only the iterator's 33554432 bytes and exited 0. Its object is the exact prefix OID `284160124c6f2e4694b0fee82bfb1fe73746b962`; the full input OID is `73cd9847570c1a6413a50a7063f8f698b62c46cf`.

These observations prove that the final 17 bytes reached the worker's Readable buffer and that the iterator had completed while those bytes remained available through read(). This run excludes first-hop loss and second-hop loss as explanations for this particular tail. It does not claim a fix, diagnose every Bun stream path, or justify reading native fd0 in production. The 64MiB and 64MiB+17 controls in the same diagnostic sequence passed and had no unread source tail.

`experiment/closed.ndjson` is raw. `large-handoff-summary.json` joins rows by actual worker PID. `status.json` records the external runner outcome and no surviving owned command. `retained-repo-inventory.json` discloses the auxiliary process-exit JSON handler again did not execute under Bun test; the native inventory found 11 retained central repositories. The failed physical Git repository `repositories/wxs-binary-git-TZ3583` is included. Independent native Node cold reading confirms all first 33554432 bytes match the expected pattern and the final 17 are absent. Expected input was regenerated from the unchanged `index % 251` rule, not claimed as an original Buffer dump.

After extraction, the actual Git object can be reread independently from this directory:

```sh
node probes/d2-cold-object-compare.mjs repositories/wxs-binary-git-TZ3583 284160124c6f2e4694b0fee82bfb1fe73746b962 experiment/input-33554449.bin /private/tmp/d2-eof-archived-actual.bin /private/tmp/d2-eof-archived-cold.json
shasum -a 256 -c MANIFEST.sha256
```

The fixture's absolute private import paths are preserved as raw provenance, not advertised as portable. The cold reader is portable on a host with Node and `/usr/bin/git`. Source and original installed package were not edited. The previous low-volume red is separately archived as `D2-LAST17-662-LOW-TRACE.tgz`, SHA256 `d5a56f4b09949a1f29f3f981c3355da7f0a61d83285e48e3ae7666c040c90487`. This archive does not close D2; R12-U1 remains deferred.
