import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { closeSync, existsSync, mkdtempSync, readFileSync, readSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { setTimeout as delay } from 'node:timers/promises'

const self = fileURLToPath(import.meta.url)
const [first, second, third] = process.argv.slice(2)

if (first === '--target') {
  const mode = second
  const marker = third
  const watchdog = setTimeout(() => process.exit(97), 8000)
  if (mode === 'digest') {
    writeFileSync(marker, JSON.stringify({ pid: process.pid, ready: true }))
    await delay(200)
    const hash = createHash('sha256')
    let size = 0
    for await (const bytes of process.stdin) {
      size += bytes.length
      hash.update(bytes)
    }
    const result = { size, sha256: hash.digest('hex') }
    writeFileSync(`${marker}.consumed`, JSON.stringify(result))
    process.stdout.write(JSON.stringify(result))
    clearTimeout(watchdog)
  } else if (mode === 'never') {
    writeFileSync(marker, JSON.stringify({ pid: process.pid, ready: true, readBytes: 0 }))
  } else if (mode === 'partial-stop' || mode === 'partial-exit') {
    const bytes = Buffer.alloc(1)
    const count = readSync(0, bytes, 0, 1, null)
    writeFileSync(marker, JSON.stringify({ pid: process.pid, ready: true, readBytes: count, byte: bytes[0] }))
    if (mode === 'partial-exit') setTimeout(() => process.exit(23), 250)
  } else if (mode === 'close') {
    closeSync(0)
    writeFileSync(marker, JSON.stringify({ pid: process.pid, ready: true, closedStdin: true }))
  } else {
    throw new Error(`Unknown target mode ${mode}`)
  }
} else {
  assert.ok(first, 'Pass a fixed library package root')
  const libraryRoot = path.resolve(first)
  const nodeExecutable = process.env.D2_NODE ?? '/opt/homebrew/bin/node'
  const resolved = {
    process: import.meta.resolve('wanxiangli/process'),
    supervision: import.meta.resolve('wanxiangli/supervision'),
  }
  for (const entry of Object.values(resolved)) assert.ok(entry.startsWith(pathToFileURL(libraryRoot).href))
  const { ProcessSession } = await import(resolved.process)
  const { SupervisedProcess } = await import(resolved.supervision)
  const root = mkdtempSync(path.join(tmpdir(), 'd2-stdin-review-'))
  const records = []
  const active = []
  const input = Buffer.alloc(33554449)
  for (let index = 0; index < input.length; index++) input[index] = index % 251
  const expected = { size: input.length, sha256: createHash('sha256').update(input).digest('hex') }
  const packageDigest = () => {
    const entries = []
    const visit = directory => {
      for (const name of readdirSync(directory).sort()) {
        const file = path.join(directory, name)
        const relative = path.relative(libraryRoot, file)
        if (relative.split(path.sep).includes('node_modules')) continue
        if (statSync(file).isDirectory()) visit(file)
        else entries.push([relative, createHash('sha256').update(readFileSync(file)).digest('hex')])
      }
    }
    visit(libraryRoot)
    return { files: entries.length, sha256: createHash('sha256').update(JSON.stringify(entries)).digest('hex') }
  }
  const before = packageDigest()
  const until = async (condition, label, timeout = 3000) => {
    const end = Date.now() + timeout
    while (!condition()) {
      assert.ok(Date.now() < end, label)
      await delay(5)
    }
  }
  const bound = (promise, label, milliseconds = 5000) => {
    let timer
    return Promise.race([
      promise,
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(label)), milliseconds) }),
    ]).finally(() => clearTimeout(timer))
  }
  const live = pid => {
    if (!pid) return false
    let result
    try { result = execFileSync('/bin/ps', ['-o', 'stat=', '-p', String(pid)], { encoding: 'utf8' }).trim() }
    catch (error) { if (error.status === 1) return false; throw error }
    return result.length > 0 && !result.startsWith('Z')
  }
  const pauseSupervisor = async owned => {
    assert.ok(owned.record.supervisor)
    process.kill(owned.record.supervisor, 'SIGSTOP')
    await until(() => execFileSync('/bin/ps', ['-o', 'stat=', '-p', String(owned.record.supervisor)], { encoding: 'utf8' }).trim().startsWith('T'), 'supervisor did not stop')
    owned.record.supervisorStoppedBeforeLargeWrite = true
  }
  const consume = async run => {
    const stdout = []
    const stderr = []
    const cursors = { stdout: 0, stderr: 0 }
    while (true) {
      const output = await run.takeOutput()
      if (output.kind === 'Chunk') {
        assert.equal(output.from, cursors[output.channel])
        assert.equal(output.to - output.from, output.bytes.length)
        cursors[output.channel] = output.to
        ;(output.channel === 'stdout' ? stdout : stderr).push(Buffer.from(output.bytes))
      } else {
        return { output, stdout: Buffer.concat(stdout), stderr: Buffer.concat(stderr), cursors }
      }
    }
  }
  const start = async (kind, mode) => {
    const marker = path.join(root, `${kind}-${mode}`)
    const Constructor = kind === 'base' ? ProcessSession : SupervisedProcess
    const run = new Constructor({
      executable: nodeExecutable,
      args: [self, '--target', mode, marker],
      cwd: root,
      env: {},
      tailBytes: 65536,
      maxWriteBytes: 16777216,
    })
    const record = { kind, mode, marker, receipts: [], target: null, supervisor: null }
    const owned = { run, record, collection: kind === 'supervised' ? consume(run) : null }
    active.push(owned)
    record.started = await bound(run.started(), 'startup timeout')
    assert.equal(record.started.kind, 'Started', JSON.stringify(record.started))
    record.target = record.started.pid
    record.supervisor = run.inspect().supervisor?.pid ?? null
    records.push(record)
    return owned
  }
  const close = async owned => {
    const { run, record, collection } = owned
    record.closed = await bound(run.wait(5000), 'close timeout', 5500)
    assert.equal(record.closed.kind, 'Closed', JSON.stringify(record.closed))
    if (collection) {
      const output = await bound(collection, 'capture timeout')
      record.capture = { terminal: output.output, cursors: output.cursors, stdout: output.stdout.toString(), stderr: output.stderr.toString() }
    } else {
      record.stdout = Buffer.from(run.read('stdout', 0).bytes).toString()
      record.stderr = Buffer.from(run.read('stderr', 0).bytes).toString()
    }
    await until(() => !live(record.target) && !live(record.supervisor), 'owned process stayed active', 3000)
    record.cleanup = { targetInactive: !live(record.target), supervisorInactive: !live(record.supervisor) }
  }
  const pendingWrite = owned => {
    let receipt
    const promise = owned.run.write(input.subarray(0, 16777216)).then(result => {
      receipt = result
      owned.record.receipts.push(result)
      return result
    })
    return { promise, get receipt() { return receipt } }
  }
  const unknown = async (owned, pending) => {
    const receipt = await bound(pending.promise, 'write stayed pending after reader termination')
    assert.equal(receipt.kind, 'Unknown', JSON.stringify(receipt))
    assert.throws(() => owned.run.write(Buffer.from([1])), /not open/)
  }
  let failure
  try {
    for (const kind of ['base', 'supervised']) {
      const full = await start(kind, 'digest')
      await until(() => existsSync(full.record.marker), 'digest ready marker')
      for (let offset = 0; offset < input.length; offset += 16777216) {
        const part = input.subarray(offset, offset + 16777216)
        const receipt = await bound(full.run.write(part), 'full input flush timeout')
        full.record.receipts.push(receipt)
        assert.deepEqual(receipt, { kind: 'Written', bytes: part.length })
      }
      full.run.endInput()
      await close(full)
      full.record.actualConsumed = JSON.parse(readFileSync(`${full.record.marker}.consumed`, 'utf8'))
      assert.deepEqual(full.record.actualConsumed, expected)
      assert.deepEqual(full.record.closed.state.exit, { code: 0, signal: null })
      assert.equal(full.record.closed.state.failure, null)

      const never = await start(kind, 'never')
      await until(() => existsSync(never.record.marker), 'never-reader ready marker')
      if (kind === 'supervised') await pauseSupervisor(never)
      const neverWrite = pendingWrite(never)
      await delay(200)
      assert.equal(neverWrite.receipt, undefined, 'unread large input must remain pending')
      never.record.beforeKill = never.run.inspect()
      assert.equal(never.record.beforeKill.phase, 'Running')
      never.record.kill = never.run.signal('SIGKILL')
      assert.equal(never.record.kill.kind, 'Requested')
      await unknown(never, neverWrite)
      await close(never)

      const closed = await start(kind, 'close')
      await until(() => existsSync(closed.record.marker), 'closed-input ready marker')
      if (kind === 'supervised') await pauseSupervisor(closed)
      const closedWrite = pendingWrite(closed)
      if (kind === 'base') {
        await unknown(closed, closedWrite)
        assert.equal(closedWrite.receipt.error.code, 'EPIPE')
        closed.record.beforeKill = closed.run.inspect()
        assert.equal(closed.record.beforeKill.phase, 'Running')
      } else {
        await delay(200)
        assert.equal(closedWrite.receipt, undefined, 'stopped worker first pipe must remain pending')
        closed.record.beforeKill = closed.run.inspect()
        assert.equal(closed.record.beforeKill.phase, 'Running')
      }
      closed.record.kill = closed.run.signal('SIGKILL')
      assert.equal(closed.record.kill.kind, 'Requested')
      if (kind === 'supervised') await unknown(closed, closedWrite)
      await close(closed)

      const partial = await start(kind, 'partial-stop')
      if (kind === 'supervised') {
        const receipt = await partial.run.write(input.subarray(0, 1))
        partial.record.receipts.push(receipt)
        assert.deepEqual(receipt, { kind: 'Written', bytes: 1 })
      }
      const partialWrite = kind === 'base' ? pendingWrite(partial) : null
      await until(() => existsSync(partial.record.marker), 'partial-reader evidence')
      partial.record.readEvidence = JSON.parse(readFileSync(partial.record.marker, 'utf8'))
      assert.equal(partial.record.readEvidence.readBytes, 1)
      assert.equal(partial.record.readEvidence.byte, input[0])
      if (kind === 'supervised') await pauseSupervisor(partial)
      const actualPartialWrite = partialWrite ?? pendingWrite(partial)
      await delay(100)
      assert.equal(actualPartialWrite.receipt, undefined, 'one-byte consumption and a stopped reader must not acknowledge all 16MiB')
      partial.record.kill = partial.run.signal('SIGKILL')
      assert.equal(partial.record.kill.kind, 'Requested')
      await unknown(partial, actualPartialWrite)
      await close(partial)

      if (kind === 'supervised') continue
      const exiting = await start(kind, 'partial-exit')
      const exitingWrite = pendingWrite(exiting)
      await until(() => existsSync(exiting.record.marker), 'exiting-reader evidence')
      exiting.record.readEvidence = JSON.parse(readFileSync(exiting.record.marker, 'utf8'))
      assert.equal(exiting.record.readEvidence.readBytes, 1)
      await delay(100)
      assert.equal(exitingWrite.receipt, undefined, 'input must be pending before the known target exit')
      await unknown(exiting, exitingWrite)
      await close(exiting)
      assert.deepEqual(exiting.record.closed.state.exit, { code: 23, signal: null })
    }
  } catch (error) {
    failure = { name: error.name, message: error.message, stack: error.stack }
    process.exitCode = 1
  } finally {
    for (const owned of active) {
      if (owned.run.inspect().phase !== 'Closed' || owned.run.inspect().supervisor?.phase === 'Running') {
        owned.record.finalCleanupSignal = owned.run.signal('SIGKILL')
        owned.run.discardOutput?.()
        owned.record.finalCleanup = await owned.run.wait(5000)
      }
      owned.record.finalState = owned.run.inspect()
    }
    rmSync(root, { recursive: true, force: true })
    const after = packageDigest()
    assert.deepEqual(after, before)
    console.log(JSON.stringify({
      runtime: process.versions.bun ? `Bun ${process.versions.bun}` : `Node ${process.version}`,
      targetRuntime: execFileSync(nodeExecutable, ['--version'], { encoding: 'utf8' }).trim(),
      libraryRoot,
      resolved,
      packageBefore: before,
      packageAfter: after,
      expected,
      records,
      failure,
      scratchRemoved: !existsSync(root),
    }, null, 2))
  }
}
