# Independent fixed-package 0.6.10 review

Candidate `wanxiangli-0.6.10.tgz`, SHA256
`13fbbfd5ca9b6d3542b8041373352fdb98117638bd76d52900e7fb5edf3e1725`.
Actually installed by npm into a new directory with a private cache, lifecycle
scripts disabled, and no runtime dependencies. Tests run on Node 26.6.0 and
Bun 1.3.14, macOS arm64. Production and source files were read-only for this
reviewer. The author separately owned the source fix.

## Results

- The original nine independent stdin cases pass on Node and all nine pass
  on Bun. Their assertions and input sizes are unchanged from the 0.6.9 review.
  They cover exact 32 MiB+17 delayed-reader delivery, never-read pending input,
  real closed-fd EPIPE, exact one-byte consumption before kill, direct exit 23
  during a pending write, and physically stopped supervisor first-pipe writes
  that must remain pending and return Unknown after kill. Later writes after
  Unknown remain rejected. Each case records Closed and ps inactive targets/
  supervisors, then removes its own scratch.
- The exact original ready Git-alias tee input of 2 MiB+17 is compared against
  fixed 0.6.9 without changing either package. Node both versions deliver every
  byte. Bun 0.6.9 again delivers only 983,040 bytes despite Written 2,097,169;
  Bun 0.6.10 delivers all 2,097,169 target-file and stdout bytes, SHA256
  `89aa92318e99cab08cca1c8f9e28532a8e261950c7421ad46e764e534358121d`,
  stderr is the original nine binary bytes, native exit 7 is retained, and
  failure is null. Each command is sent once; no Unknown is retried.
- An additional independent early-refusal case runs a real shell which closes
  fd 0, prints before/after output with a delay, prints a diagnostic to stderr,
  and exits 23. Node and Bun preserve both complete channels, actual exit 23,
  null failure and Closed. A first-pipe Written or Unknown is recorded according
  to actual transport completion; neither is treated as final-target input
  consumption. This separate test checks that iterator return does not destroy
  runtime stdin and turn a legitimate target refusal into a source failure.
- Fixed-tarball `SPEC[build-007]` passes 5/5, no skip: strict TypeScript public
  declarations; remove all unrelated module dist/source; remove all source;
  Node/Bun supervision consumers; then remove supervision dist and run Node/Bun
  base consumers. This is actual installed-package execution, not source fallback.
- The two selected `SPEC[build-001]` source-closure gates pass 2/2, no skip.
  Process compiles and runs its own tests without sibling-owner sources.
  Supervision compiles and runs its own tests with only its owner and the
  explicit shared Bun native adapter, using the delivered Process artifact.
  The Fable compiler is a declared test-only dependency from the author checkout.
  These two source-build gates are distinct from fixed-package verification.

All 22 installed package files keep the same before/after aggregate digest:
`35669076a93ee569d7083dbcd3e810d37ba18f29c969aab4a775e9cd2a90be34`.
The baseline's 22 files also remain unchanged. Digests hash sorted relative
paths and file SHA256 pairs, not tar encoding. Raw run files retain target and
supervisor cleanup receipts. The final main-package F# same-program test is
still separate and has not been passed by this library-only result.

The earlier candidate-659 typed failure and 0.6.8/0.6.9 observable comparison
are preserved in their own archives. No older failure is erased by this green.
One summary-only check mistakenly expected JSON `failure:null`, but the existing
probe omits an undefined failure field on success. This was corrected to check
absence of a failure; no runtime assertion, input or expected result changed.

## Replay

In this archive directory, install the candidate into its own consumer. The
stdin probe must reside in that consumer so actual ESM exports resolve there.
Override D2_NODE with the absolute Node target executable on other hosts.

```sh
mkdir consumer
npm install --prefix consumer --cache "$PWD/npm-cache" --ignore-scripts --no-audit --no-fund "$PWD/wanxiangli-0.6.10.tgz"
cp d2-independent-stdin-review.mjs consumer/probe.mjs
D2_NODE="$(command -v node)" node consumer/probe.mjs "$PWD/consumer/node_modules/wanxiangli"
D2_NODE="$(command -v node)" bun consumer/probe.mjs "$PWD/consumer/node_modules/wanxiangli"
node d2-input-early-close.mjs "$PWD/consumer/node_modules/wanxiangli"
bun d2-input-early-close.mjs "$PWD/consumer/node_modules/wanxiangli"
```

Install the included 0.6.9 tarball into a separate directory and pass the two
installed package roots to `d2-supervised-068-069-comparison.mjs` to repeat the
original tee red/green comparison. Its filename reflects its first use; the
script reads and records actual package versions and is unchanged here.

The package/type/removal gate can run with the four included gate fixtures and
TypeScript 7.0.2 installed as a test-only dependency in the `gate` directory:

```sh
npm install --prefix gate --cache "$PWD/npm-cache" --no-audit --no-fund typescript@7.0.2
WANXIANGLI_TEST_TARBALL="$PWD/wanxiangli-0.6.10.tgz" node --test gate/scripts/tests/supervision-package.test.mjs
```

The source-closure command requires the matching 0.6.10 source checkout and its
declared Fable toolchain. It is recorded in `commands.txt`, alongside hashes of
the source inputs read for this review. No dotnet build is used.
