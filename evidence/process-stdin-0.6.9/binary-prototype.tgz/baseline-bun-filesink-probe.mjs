import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'

assert.ok(process.versions.bun)
const bytes = Buffer.alloc(2 * 16 * 1024 * 1024 + 17)
for (let index = 0; index < bytes.length; index++) bytes[index] = index & 0xff
const expected = createHash('sha1').update(Buffer.from(`blob ${bytes.length}\0`)).update(bytes).digest('hex')

async function observe(chunkBytes, slow) {
  const source = "import { readFileSync, writeFileSync } from 'node:fs'; import { createHash } from 'node:crypto'; setTimeout(() => {const b=readFileSync(0);writeFileSync(1,createHash('sha1').update(Buffer.from('blob '+b.length+'\\0')).update(b).digest('hex')+'\\n')},200);"
  const command = slow ? [process.execPath, '--input-type=module', '-e', source] : ['/usr/bin/git', 'hash-object', '--stdin']
  const child = Bun.spawn(command, { stdin: 'pipe', stdout: 'pipe', stderr: 'pipe', env: { ...process.env } })
  const stdout = new Response(child.stdout).arrayBuffer()
  const stderr = new Response(child.stderr).arrayBuffer()
  const timer = setTimeout(() => child.kill('SIGKILL'), 5000)
  const writes = []
  try {
    for (let offset = 0; offset < bytes.length; offset += chunkBytes) {
      const chunk = bytes.subarray(offset, Math.min(offset + chunkBytes, bytes.length))
      const count = await child.stdin.write(chunk)
      const flushed = await child.stdin.flush()
      writes.push({ requested: chunk.length, count, flushed })
    }
    const ended = await child.stdin.end()
    const code = await child.exited
    const actual = Buffer.from(await stdout).toString().trim()
    const error = Buffer.from(await stderr).toString()
    assert.equal(code, 0, error)
    assert.equal(actual, expected)
    return { chunkBytes, slow, inputBytes: bytes.length, chunks: writes.length, partialWriteCount: writes.filter(write => write.count !== write.requested).length, examples: writes.filter(write => write.count !== write.requested).slice(0, 5), sumCounts: writes.reduce((sum, write) => sum + write.count, 0), sumFlushed: writes.reduce((sum, write) => sum + write.flushed, 0), ended, actualOid: actual, expectedOid: expected, targetCode: code }
  } finally {
    clearTimeout(timer)
  }
}

const results = []
for (const chunkBytes of [16 * 1024 * 1024, 65536]) {
  for (const slow of [false, true]) results.push(await observe(chunkBytes, slow))
}
console.log(JSON.stringify({ runtime: process.versions.bun, results }, null, 2))
