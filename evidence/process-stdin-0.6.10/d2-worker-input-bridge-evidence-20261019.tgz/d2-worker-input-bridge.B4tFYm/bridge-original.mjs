import process from 'node:process'
import { writeFileSync } from 'node:fs'
import { Transform } from 'node:stream'
import { setTimeout as delay } from 'node:timers/promises'
import { ownedNativeSpawn, ownedNativeOutput } from './fixed-supervision-private-export.mjs'

const [mode, repo, witness, tracePath] = process.argv.slice(2)
const trace = { mode, pid: process.pid, sourceBytes: 0, sourceChunks: [], sourceEnded: false, sourceClosed: false, writes: [], final: [], targetExit: null, targetClosed: false, stdoutBytes: 0, stderrBytes: 0, errors: [], stdoutForwarded: false, stderrForwarded: false }
const alias = "alias.d2-status=!f() { tee \"$2\"; printf '\\000\\377stderr\\n' >&2; exit \"$1\"; }; f"
const child = ownedNativeSpawn('/usr/bin/git', ['-C', repo, '-c', alias, 'd2-status', '7', witness], { cwd: repo, env: { PATH: process.env.PATH }, detached: false })
const save = () => writeFileSync(tracePath, JSON.stringify(trace, null, 2) + '\n')
const inputWrite = child.stdin._write
child.stdin._write = function (bytes, encoding, callback) {
  const write = { bytes: bytes.length, callback: false, error: null }
  trace.writes.push(write)
  inputWrite.call(this, bytes, encoding, error => {
    write.callback = true
    write.error = error ? { message: error.message, code: error.code ?? null } : null
    callback(error)
  })
}
const inputFinal = child.stdin._final
child.stdin._final = function (callback) {
  const final = { invoked: true, callback: false, error: null }
  trace.final.push(final)
  inputFinal.call(this, error => {
    final.callback = true
    final.error = error ? { message: error.message, code: error.code ?? null } : null
    callback(error)
  })
}
child.stdin.on('error', error => trace.errors.push({ phase: 'target-stdin', message: error.message, code: error.code ?? null }))
child.on('error', error => trace.errors.push({ phase: 'target', message: error.message, code: error.code ?? null }))
child.on('exit', (code, signal) => { trace.targetExit = { code, signal } })
child.on('close', () => { trace.targetClosed = true })
const outputs = []
for (const channel of ['stdout', 'stderr']) {
  const output = ownedNativeOutput(channel === 'stdout' ? 1 : 2)
  outputs.push(output)
  output.on('error', error => trace.errors.push({ phase: `${channel}-forward`, message: error.message, code: error.code ?? null }))
  child[channel].on('error', error => trace.errors.push({ phase: channel, message: error.message, code: error.code ?? null }))
  const counted = new Transform({ transform(bytes, encoding, callback) { trace[`${channel}Bytes`] += bytes.length; callback(null, bytes) } })
  counted.once('end', () => { trace[`${channel}Forwarded`] = true })
  child[channel].pipe(counted).pipe(output, { end: false })
}
process.stdin.on('error', error => trace.errors.push({ phase: 'source-stdin', message: error.message, code: error.code ?? null }))
process.stdin.on('end', () => { trace.sourceEnded = true })
process.stdin.on('close', () => { trace.sourceClosed = true })
if (mode === 'pipe') {
  process.stdin.on('data', bytes => { trace.sourceBytes += bytes.length; trace.sourceChunks.push(bytes.length) })
  process.stdin.pipe(child.stdin, { end: true })
} else if (mode === 'serial') {
  ;(async () => {
    try {
      for await (const bytes of process.stdin) {
        trace.sourceBytes += bytes.length
        trace.sourceChunks.push(bytes.length)
        await new Promise((resolve, reject) => child.stdin.write(bytes, error => error ? reject(error) : resolve()))
      }
      await new Promise((resolve, reject) => child.stdin.end(error => error ? reject(error) : resolve()))
    } catch (error) {
      trace.errors.push({ phase: 'serial-forward', message: error.message, code: error.code ?? null })
    }
  })()
} else throw new Error('Unknown owned bridge mode')
const end = performance.now() + 10000
while ((!trace.targetClosed || !trace.stdoutForwarded || !trace.stderrForwarded || outputs.some(output => output.writableLength > 0)) && performance.now() < end) await delay(5)
save()
if (!trace.targetClosed) {
  try { process.kill(child.pid, 'SIGKILL') } catch {}
  process.exit(124)
}
process.exit(trace.targetExit?.code ?? 125)
